// Alterna secções do dashboard
const tabs = document.querySelectorAll('.admin-tab');
const secs = document.querySelectorAll('.admin-section');
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    secs.forEach(s => s.classList.add('hide'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.sec).classList.remove('hide');
  });
});

// Checkbox “Não encontrado” em Dados Pessoais
document.querySelectorAll('.not-found').forEach(chk => {
  chk.addEventListener('change', () => {
    const targetId = chk.dataset.target;
    const input = document.getElementById(targetId);

    if (chk.checked) {
      input.value = 'Sem informação';
      input.disabled = true;
    } else {
      input.value = '';
      input.disabled = false;
    }
  });
});

// Mostrar/ocultar detalhes de ataque apenas quando “Sim” for selecionado
const yesRadio = document.querySelector('input[name="ataque"][value="yes"]');
const noRadio  = document.querySelector('input[name="ataque"][value="no"]');
const details  = document.getElementById('attack-details');

// Garante que começa oculto
details.classList.add('hide');

yesRadio.addEventListener('change', () => {
  if (yesRadio.checked) details.classList.remove('hide');
});
noRadio.addEventListener('change', () => {
  if (noRadio.checked) details.classList.add('hide');
});





document.addEventListener('DOMContentLoaded', () => {
  const userIcon = document.getElementById('user-icon');
  const userPopup = document.getElementById('user-popup');

  if (userIcon && userPopup) {
    userIcon.addEventListener('click', () => {
      userPopup.classList.toggle('hide');
    });

    // Fecha o popup ao clicar fora
    document.addEventListener('click', (e) => {
      if (!userIcon.contains(e.target) && !userPopup.contains(e.target)) {
        userPopup.classList.add('hide');
      }
    });
  }
});

