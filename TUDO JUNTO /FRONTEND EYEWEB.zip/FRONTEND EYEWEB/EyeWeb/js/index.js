// Tabs funcionamento
const tabs = document.querySelectorAll('.tab');
const contents = document.querySelectorAll('.tab-content');
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    contents.forEach(c => c.classList.add('hide'));
    document.getElementById(tab.dataset.target).classList.remove('hide');
  });
});

// Personal data buttons
const personalBtns = document.querySelectorAll('.tab-buttons button');
const personalInput = document.getElementById('personal-input');
personalBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    personalBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const type = btn.dataset.type;
    personalInput.placeholder = `Enter ${type}`;
  });
});

// Stub de resultados (estáticos)
document.getElementById('personal-search').addEventListener('click', () => {
  document.getElementById('personal-result').textContent =
    'Found leak on 2024-11-03 in leaked_data_001.txt';
});
document.getElementById('link-search').addEventListener('click', () => {
  document.getElementById('link-result').textContent =
    'Link identified as malicious on 2025-02-12';
});
document.getElementById('password-search').addEventListener('click', () => {
  document.getElementById('password-result').textContent =
    'Password strength: Weak (found in 10 leaks)';
});
