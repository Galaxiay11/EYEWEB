
document.addEventListener('DOMContentLoaded', () => {
  const userIcon = document.getElementById('user-icon');
  const userPopup = document.getElementById('user-popup');

  if (userIcon && userPopup) {
    userIcon.addEventListener('click', () => {
      userPopup.classList.toggle('hide');
    });

    // Fecha o popup ao clicar fora
    document.addEventListener('click', (e) => {
      if (!userIcon.contains(e.target) && !userPopup.contains(e.target)) {
        userPopup.classList.add('hide');
      }
    });
  }
});
