document.addEventListener('DOMContentLoaded', () => {
    const eyeContainer = document.getElementById('eyeContainer');
    const pupil = eyeContainer.querySelector('.pupil');
    const afterClick = document.getElementById('afterClick');

    function onMouseMove(e) {
        const rect = eyeContainer.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;

        const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX);
        const maxDistance = 25;
        const distance = Math.min(maxDistance, Math.hypot(e.clientX - centerX, e.clientY - centerY) / 5);

        pupil.style.transform = `translate(-50%, -50%) translate(${Math.cos(angle) * distance}px, ${Math.sin(angle) * distance}px)`;
    }

    document.addEventListener('mousemove', onMouseMove);

    eyeContainer.addEventListener('click', () => {
        document.removeEventListener('mousemove', onMouseMove);
        pupil.style.transform = 'translate(-50%, -50%)';
        eyeContainer.classList.add('clicked');

        setTimeout(() => {
            eyeContainer.style.display = 'none';
            afterClick.classList.remove('hidden');
            afterClick.classList.add('show');
        }, 3000);
    });

    // Botões principais (opções)
    const optionButtons = document.querySelectorAll('.option-btn');
    const sections = document.querySelectorAll('.section');

    optionButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Limpa estados
            optionButtons.forEach(b => b.classList.remove('clicked'));
            sections.forEach(s => s.classList.add('hidden'));

            // Marca botão clicado e mostra seção correspondente
            btn.classList.add('clicked');
            const targetId = btn.getAttribute('data-section');
            document.getElementById(targetId).classList.remove('hidden');
        });
    });

    // Sub-botões dentro Dados Pessoais
    const subBtns = document.querySelectorAll('#dadosPessoais .sub-btn');
    const dadosInput = document.getElementById('dadosInput');

    subBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            subBtns.forEach(b => b.classList.remove('clicked'));
            btn.classList.add('clicked');
            if(btn.textContent === 'Email') {
                dadosInput.type = 'text';
                dadosInput.placeholder = 'Escreva o email';
            } else {
                dadosInput.type = 'tel';
                dadosInput.placeholder = 'Escreva o número de telemóvel';
            }
            dadosInput.value = '';
        });
    });
});
