<?php
require_once __DIR__ . '/inc/defense_bootstrap.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }
session_destroy(); // Apaga todos os dados da sessão
header('Location: index.php'); // Redireciona para o login
exit();
