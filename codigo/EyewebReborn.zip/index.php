<?php
require_once __DIR__ . '/inc/defense_bootstrap.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Não destruir a sessão do admin ao visitar a página pública — necessário para o painel em tempo real

require_once __DIR__ . '/security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = null;
$db_error = null;
try {
  $pdo = getPDO();
} catch (Throwable $e) {
  $db_error = $e->getMessage();
}

// Forçar um registo mínimo de visita via PDO caso o guard não tenha executado
if ($pdo) {
  try {
    // evitar duplicar registos em excesso: cookie curto
    $touchCooldown = $_COOKIE['ew_touch'] ?? '';
    $deviceId = $_COOKIE['device_id'] ?? null;
    if (!$deviceId) {
      try{ $deviceId = 'd_'.bin2hex(random_bytes(6)).'_'.dechex(time()); }catch(Throwable $e){ $deviceId='d_'.uniqid(); }
      @setcookie('device_id',$deviceId,['expires'=>time()+365*24*3600,'path'=>'/','samesite'=>'Lax']);
    }
    if ($touchCooldown !== '1' && $deviceId) {
      $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
      if ($ip === '::1') $ip = '127.0.0.1';
      $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
      $now = date('Y-m-d H:i:s');
      $stmt = $pdo->prepare('INSERT INTO visits (ip,user_agent,ts,blocked,notes,device_id,last_seen) VALUES (?,?,?,?,?,?,?)');
      $stmt->execute([$ip,$ua,$now,0,'index-touch',$deviceId,$now]);
      @setcookie('ew_touch','1',['expires'=>time()+300,'path'=>'/','samesite'=>'Lax']);
    }
  } catch (Throwable $e) {
    // silenciar, página pública não deve falhar
  }
}

$resultData = null;
$mensagemPersonalizada = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!$pdo) {
    // Base de dados indisponível: responder com mensagem amigável, sem falhar com 500
    $mensagemPersonalizada = 'Serviço temporariamente indisponível: não foi possível ligar à base de dados.';
  } else {
    if (isset($_POST['type']) && isset($_POST['query'])) {
        $type = $_POST['type'];
        $query = trim($_POST['query']);

    if ($type === 'email') {
      $stmt = $pdo->prepare("SELECT * FROM personal_data WHERE email = ?");
      $stmt->execute([$query]);
      $resultData = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$resultData) {
        $mensagemPersonalizada = 'Tudo em ordem! Dados não encontrados na nossa base de dados';
      }
    } elseif ($type === 'phone') {
      $stmt = $pdo->prepare("SELECT * FROM personal_data WHERE phone = ?");
      $stmt->execute([$query]);
      $resultData = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$resultData) {
        $mensagemPersonalizada = 'Tudo em ordem! Dados não encontrados na nossa base de dados';
      }
    } elseif ($type === 'url') {
      $stmt = $pdo->prepare("SELECT * FROM malicious_links WHERE url LIKE ?");
      $searchUrl = '%' . $query . '%';
      $stmt->execute([$searchUrl]);
      $urlData = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($urlData) {
                $problemas = [];
                if ($urlData['phishing']) $problemas[] = "Phishing";
                if ($urlData['insecure']) $problemas[] = "Inseguro";
                if ($urlData['coleta']) $problemas[] = "Coleta de Dados";

                $resultData = [
                    'status' => 'dangerous',
                    'message' => 'URL maliciosa encontrada!',
                    'problemas' => !empty($problemas) ? implode(" / ", $problemas) : "Nenhum problema específico detectado",
                    'ataque' => $urlData['attack_type'] ?? "Tipo de ataque não especificado",
                    'data_ataque' => $urlData['attack_date'] ? date('d/m/Y', strtotime($urlData['attack_date'])) : "Data não disponível"
                ];
            } else {
                $resultData = [
                    'status' => 'safe' // Mensagem removida aqui
                ];
            }
    } elseif ($type === 'password') {
      $stmt = $pdo->prepare("SELECT * FROM password_data WHERE password = ?");
      $stmt->execute([$query]);
      $passData = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($passData) {
                $messages = [
                    'fraca' => [
                        'class' => 'safe',
                        'message' => 'Esta senha não foi encontrada em vazamentos conhecidos',
                        'advice' => '✅ Esta senha parece segura contra vazamentos conhecidos'
                    ],
                    'media' => [
                        'class' => 'warning',
                        'message' => 'Esta senha foi encontrada em alguns vazamentos',
                        'advice' => '🔸 Esta senha apareceu em alguns vazamentos - considere alterá-la'
                    ],
                    'forte' => [
                        'class' => 'danger',
                        'message' => 'Esta senha foi amplamente comprometida em vazamentos',
                        'advice' => '⚠️ Esta senha está altamente comprometida - NÃO USE!'
                    ]
                ];

                $resultData = [
                    'status' => $messages[$passData['category']]['class'],
                    'message' => $messages[$passData['category']]['message'],
                    'advice' => $messages[$passData['category']]['advice'],
                    'strength' => $passData['category']
                ];
            } else {
                $resultData = [
                    'status' => 'unknown',
                    'message' => 'Senha não encontrada na base de dados',
                    'advice' => 'Esta senha não foi encontrada em nossos registros de vazamentos',
                    'strength' => 'unknown'
                ];
            }
  }
    }
}
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EyeWeb</title>
  <link rel="stylesheet" href="css/index.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <noscript>
    <style>
      .eye-screen{display:none !important}
      .after-click.hidden{display:block !important}
      body.dark{overflow:auto}
    </style>
  </noscript>
</head>
<body class="dark">

  <div class="eye-screen">
    <div class="eye-container" id="eyeContainer"><div class="eye"><div class="pupil"></div></div></div>
  </div>

  <div id="afterClick" class="after-click hidden">
    <nav class="navbar">
      <a href="index.php" class="logo-text">EyeWeb</a>
      <div class="navbar-right">
    <a href="about.php" class="nav-link">About</a>
  <a href="defense.php" class="nav-icon" title="Defense"><i class="fa-solid fa-user-shield"></i></a>
      </div>
    </nav>

    <header class="header container"><h1>EyeWeb</h1></header>

    <main class="container">
      <?php if ($db_error): ?>
        <div style="background:#3a1f1f;color:#ffdcdc;border:1px solid #7a3b3b;padding:10px 12px;border-radius:6px;margin:8px 0;">
          <strong>Aviso:</strong> Problema ao ligar à base de dados. Verifique as credenciais em <code>security/config.php</code> no servidor.
        </div>
      <?php endif; ?>
      <p class="tagline">Analise emails, URLs e passwords para detetar vazamentos, malwares e ataques.</p>

      <nav class="tabs">
        <button class="tab active" data-target="tab-personal">PERSONAL DATA</button>
        <button class="tab" data-target="tab-url">URL CHECK</button>
        <button class="tab" data-target="tab-password">PASSWORD CHECK</button>
      </nav>

      <!-- PERSONAL DATA -->
      <section id="tab-personal" class="tab-content">
        <div class="card">
          <div class="tab-buttons">
            <button data-type="email" class="active">Email</button>
            <button data-type="phone">Phone</button>
          </div>
          <input type="text" id="personal-input" placeholder="Verifique o email">
          <button id="personal-search">Search</button>
          <div id="personal-result" class="result">
            <?php if (isset($_POST['type']) && ($_POST['type'] === 'email' || $_POST['type'] === 'phone')): ?>
              <div class="result-container">
                <?php if (!empty($resultData)): ?>
                  <h3><?= htmlspecialchars(ucfirst($_POST['type'])) ?> encontrado</h3>
                  <div class="related-data">
                    <?php if (isset($resultData['name'])): ?>
                      <p><strong>Nome:</strong> <?= htmlspecialchars($resultData['name']) ?></p>
                    <?php endif; ?>
                    <?php if (isset($resultData['email'])): ?>
                      <p><strong>Email:</strong> <?= htmlspecialchars($resultData['email']) ?></p>
                    <?php endif; ?>
                    <?php if (isset($resultData['phone'])): ?>
                      <p><strong>Número:</strong> <?= htmlspecialchars($resultData['phone']) ?></p>
                    <?php endif; ?>
                  </div>
                <?php else: ?>
                  <p class="success"><?= $mensagemPersonalizada ?></p>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </section>

      <!-- URL CHECK -->
      <section id="tab-url" class="tab-content hide">
        <div class="card">
          <input type="url" id="link-input" placeholder="Adicione o link que quer verificar">
          <button id="link-search">Check Link</button>
          <div id="link-result" class="result">
            <?php if ($resultData && isset($_POST['type']) && $_POST['type'] === 'url'): ?>
              <div class="result-container">
                <h3>Resultado da Verificação de URL</h3>
                <div class="status-badge <?= $resultData['status'] === 'dangerous' ? 'danger' : 'safe' ?>">
                  <?= strtoupper($resultData['status']) ?>
                </div>
                <?php if (isset($resultData['message'])): ?>
                  <p><?= htmlspecialchars($resultData['message']) ?></p>
                <?php endif; ?>
                <?php if ($resultData['status'] === 'dangerous'): ?>
                  <div class="url-details">
                    <h4>Problemas Detectados:</h4>
                    <p><?= htmlspecialchars($resultData['problemas']) ?></p>
                    <h4>Ataques realizados:</h4>
                    <p><?= htmlspecialchars($resultData['ataque']) ?></p>
                    <h4>Data do ataque:</h4>
                    <p><?= htmlspecialchars($resultData['data_ataque']) ?></p>
                  </div>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </section>

      <!-- PASSWORD CHECK -->
      <section id="tab-password" class="tab-content hide">
        <div class="card">
          <input type="text" id="password-input" placeholder="Verifique a sua password">
          <button id="password-search">Verify Password</button>
          <div id="password-result" class="result">
            <?php if ($resultData && isset($_POST['type']) && $_POST['type'] === 'password'): ?>
              <div class="result-container">
                <h3>Resultado da verificação de senha</h3>
                <div class="status-badge <?= $resultData['status'] ?>">
                  <?= strtoupper($resultData['status']) ?>
                </div>
                <p><?= htmlspecialchars($resultData['message']) ?></p>
                <p class="password-<?= $resultData['strength'] ?>">
                  <?= htmlspecialchars($resultData['advice']) ?>
                </p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </section>
    </main>
  </div>

  <script src="js/index.js"></script>
  <script src="/integration/eyeweb_tracker.js" defer></script>
</body>
</html>
