<?php
@date_default_timezone_set('Europe/Lisbon');
$cfg = require __DIR__ . '/config.php';

function getPDO(){
  static $pdo; if($pdo) return $pdo;
  $cfg = require __DIR__ . '/config.php';
  $host = $cfg['db_host'] ?? '127.0.0.1';
  $port = (int)($cfg['db_port'] ?? 3306);
  $db   = $cfg['db_name'] ?? '';
  $dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";
  $opt = [ PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC ];
  try{ return $pdo = new PDO($dsn, $cfg['db_user'], $cfg['db_pass'], $opt); }
  catch(Exception $e){
    $msg = $e->getMessage();
    if(($cfg['display_db_errors'] ?? false)) throw new RuntimeException('DB fail: '.$msg);
    throw new RuntimeException('DB connection failed. Check EyeWeb/security/config.php');
  }
}

function ensure_schema(){
  $pdo = getPDO();
  $pdo->exec("CREATE TABLE IF NOT EXISTS visits (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    user_agent TEXT,
    ts DATETIME NOT NULL,
    blocked TINYINT(1) NOT NULL DEFAULT 0,
    notes VARCHAR(191) NULL,
    device_id VARCHAR(64) NULL,
    country VARCHAR(64) NULL,
    region VARCHAR(64) NULL,
    city VARCHAR(128) NULL,
    lat DECIMAL(9,6) NULL,
    lon DECIMAL(9,6) NULL,
    org VARCHAR(191) NULL,
    vpn TINYINT(1) NULL,
    proxy TINYINT(1) NULL,
    tor TINYINT(1) NULL,
    last_seen DATETIME NULL,
    INDEX(ip), INDEX(ts)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
  $pdo->exec("CREATE TABLE IF NOT EXISTS blocked_ips (
    ip VARCHAR(45) PRIMARY KEY,
    blocked_at DATETIME NOT NULL,
    reason VARCHAR(191) NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
  $pdo->exec("CREATE TABLE IF NOT EXISTS blocked_devices (
    device_id VARCHAR(64) PRIMARY KEY,
    blocked_at DATETIME NOT NULL,
    reason VARCHAR(191) NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

  // Attacks table: records detected malicious requests and when they were blocked
  $pdo->exec("CREATE TABLE IF NOT EXISTS attacks (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    device_id VARCHAR(64) NULL,
    method VARCHAR(10) NOT NULL,
    path VARCHAR(255) NOT NULL,
    query TEXT NULL,
    body TEXT NULL,
    user_agent TEXT NULL,
    rule VARCHAR(64) NOT NULL,
    snippet VARCHAR(255) NULL,
    blocked TINYINT(1) NOT NULL DEFAULT 1,
    detected_at DATETIME NOT NULL,
    blocked_at DATETIME NULL,
    reason VARCHAR(191) NULL,
    INDEX(ip), INDEX(detected_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
}

function is_ip_blocked($ip){
  try{
    $pdo = getPDO();
    $s=$pdo->prepare('SELECT 1 FROM blocked_ips WHERE ip=? LIMIT 1');
    $s->execute([$ip]); return (bool)$s->fetchColumn();
  }catch(Exception $e){ return false; }
}
function is_device_blocked($d){
  if(!$d) return false; try{ $pdo=getPDO(); $s=$pdo->prepare('SELECT 1 FROM blocked_devices WHERE device_id=? LIMIT 1'); $s->execute([$d]); return (bool)$s->fetchColumn(); }catch(Exception $e){return false;}
}
function now_lisbon(){ return date('Y-m-d H:i:s'); }
