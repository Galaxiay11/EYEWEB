<?php
// Guard local para EyeWeb: device cookie, bloqueio por dispositivo/IP e registo de visitas
require_once __DIR__ . '/db.php';

// Simple debug logger (appends to security/error.log)
$__EW_LOG_FILE = __DIR__ . '/error.log';
$__ew_log = function($line) use ($__EW_LOG_FILE){
  $ts = date('Y-m-d H:i:s');
  @file_put_contents($__EW_LOG_FILE, "[GUARD $ts] $line\n", FILE_APPEND);
};

// Garantir schema
try { ensure_schema(); } catch (Throwable $e) {}

function eyeweb_sec_ip(){
  if(!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
  if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){ $p=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR']); return trim($p[0]); }
  return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

// Cookie de dispositivo
$deviceId = $_COOKIE['device_id'] ?? null;
if(!$deviceId){
  try{ $deviceId = 'd_'.bin2hex(random_bytes(6)).'_'.dechex(time()); }catch(Throwable $e){ $deviceId='d_'.uniqid(); }
  setcookie('device_id',$deviceId,['expires'=>time()+365*24*3600,'path'=>'/','samesite'=>'Lax']);
}

$ip = eyeweb_sec_ip();
$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Simple attack detection and auto-blocking
function ew_detect_attack_rule($uri, $method, $queryStr, $body, $headers){
  $hay = strtolower(($uri.' '.$queryStr.' '.substr($body,0,1000)));
  $rules = [
    'sql_union' => 'union select',
    'sql_or_1' => "' or 1=1",
    'sql_sleep' => 'sleep(',
    'path_traversal' => '../',
    'xss_script' => '<script',
    'xss_encoded' => '%3cscript',
    'passwd_probe' => 'etc/passwd',
    'shellshock' => '() { :;};',
  ];
  foreach($rules as $k=>$needle){ if (strpos($hay, $needle)!==false) return $k; }
  return null;
}

function ew_block_and_record_attack($ip, $deviceId, $method, $path, $queryStr, $body, $ua, $rule, $snippet){
  try{
    $pdo = getPDO();
    // record attack
    $stmt = $pdo->prepare('INSERT INTO attacks(ip,device_id,method,path,query,body,user_agent,rule,snippet,blocked,detected_at,blocked_at,reason) VALUES (?,?,?,?,?,?,?,?,?,1,?,?,?)');
    $stmt->execute([$ip,$deviceId,$method,$path,$queryStr,substr($body,0,4000),$ua,$rule,substr($snippet,0,255), now_lisbon(), now_lisbon(), 'auto-block']);
    // block ip if not already
    $stmt2 = $pdo->prepare('INSERT IGNORE INTO blocked_ips (ip, blocked_at, reason) VALUES (?, ?, ?)');
    $stmt2->execute([$ip, now_lisbon(), 'auto-attack']);
  }catch(Throwable $e){ /* ignore */ }
}

// Inspect request
$uri = $_SERVER['REQUEST_URI'] ?? '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$queryStr = $_SERVER['QUERY_STRING'] ?? '';
$rawBody = '';
if (in_array($method, ['POST','PUT','PATCH'])){ $rawBody = file_get_contents('php://input'); }
// If this is an API or AJAX request, skip heavy attack detection and rate-limiting
$path = parse_url($uri, PHP_URL_PATH) ?: $uri;
if (strpos($path, '/api/') === 0 || (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')){
  try{ $pdo=getPDO(); $pdo->prepare('INSERT INTO visits (ip,user_agent,ts,blocked,notes,device_id,last_seen) VALUES (?,?,?,?,?,?,?)')->execute([$ip,$ua,now_lisbon(),0,'api',$deviceId,now_lisbon()]); }catch(Throwable $e){}
  // mark guard active and stop further blocking checks for API endpoints
  if (isset($__ew_log)) $__ew_log("API_SKIP ip=$ip path=$path");
  return;
}
$rule = ew_detect_attack_rule($uri, $method, $queryStr, $rawBody, $_SERVER);
if ($rule){
  $__ew_log("ATTACK_DETECTED rule=$rule ip=$ip device=$deviceId uri=$uri");
  ew_block_and_record_attack($ip, $deviceId, $method, parse_url($uri, PHP_URL_PATH) ?: $uri, $queryStr, $rawBody, $ua, $rule, $queryStr ?: $rawBody ?: $uri);
  http_response_code(403);
  echo '<!doctype html><meta charset="utf-8"><title>Acesso bloqueado</title><body style="font-family:Arial;max-width:700px;margin:40px auto"><h1>Acesso bloqueado</h1><p>O seu acesso foi automaticamente bloqueado por atividade maliciosa.</p></body>';
  exit;
}

// Basic DDoS rate-limit: if too many requests in a short window, auto-block
try {
  $pdoRL = getPDO();
  // Count requests from this IP in the last 10 seconds (visits table)
  $stmtRL = $pdoRL->prepare('SELECT COUNT(*) FROM visits WHERE ip = ? AND ts >= DATE_SUB(NOW(), INTERVAL 10 SECOND)');
  $stmtRL->execute([$ip]);
  $count10s = (int)$stmtRL->fetchColumn();
  $threshold = 20; // mais sensível para testes; ajustar em produção
  $nextCount = $count10s + 1; // incluir o pedido atual
  if ($nextCount >= $threshold) {
    $__ew_log("DDOS_RATE ip=$ip count10s=$count10s threshold=$threshold");
    ew_block_and_record_attack($ip, $deviceId, $method, parse_url($uri, PHP_URL_PATH) ?: $uri, $queryStr, $rawBody, $ua, 'ddos_rate', 'requests_10s='.$nextCount);
    http_response_code(403);
    echo '<!doctype html><meta charset="utf-8"><title>Acesso bloqueado</title><body style="font-family:Arial;max-width:700px;margin:40px auto"><h1>Acesso bloqueado</h1><p>O seu acesso foi temporariamente bloqueado por excesso de requisições.</p></body>';
    exit;
  }
} catch (Throwable $e) { /* ignore rate-limit errors */ }

if (is_ip_blocked($ip) || is_device_blocked($deviceId)){
  try{ $pdo=getPDO(); $stmt=$pdo->prepare('INSERT INTO visits (ip,user_agent,ts,blocked,notes,device_id,last_seen) VALUES (?,?,?,?,?,?,?)'); $stmt->execute([$ip,$ua,now_lisbon(),1,'blocked-access',$deviceId,now_lisbon()]); }catch(Throwable $e){}
  $__ew_log("BLOCKED ip=$ip device=$deviceId");
  http_response_code(403);
  echo '<!doctype html><meta charset="utf-8"><title>Acesso bloqueado</title><body style="font-family:Arial;max-width:700px;margin:40px auto"><h1>Acesso bloqueado</h1><p>O seu acesso foi bloqueado.</p></body>';
  exit;
}

// Registar visita
try{ $pdo=getPDO(); $pdo->prepare('INSERT INTO visits (ip,user_agent,ts,blocked,notes,device_id,last_seen) VALUES (?,?,?,?,?,?,?)')->execute([$ip,$ua,now_lisbon(),0,'eyeweb',$deviceId,now_lisbon()]); $__ew_log("VISIT ip=$ip device=$deviceId"); }catch(Throwable $e){ $__ew_log('VISIT_ERROR '.$e->getMessage()); }
