<?php
require __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');

function json_input(){ $raw=file_get_contents('php://input'); $j=json_decode($raw,true); return is_array($j)?$j:[]; }
try{ ensure_schema(); }catch(Exception $e){}

function visitor_ip(){
  if(!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
  if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){ $parts=explode(',',$_SERVER['HTTP_X_FORWARDED_FOR']); return trim($parts[0]); }
  return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

$ip = visitor_ip(); $ua = $_SERVER['HTTP_USER_AGENT'] ?? ''; $b = json_input();
$dev = isset($b['device_id']) ? substr(preg_replace('/[^a-zA-Z0-9_-]/','',$b['device_id']),0,64) : null;
$country=$b['country']??null; $region=$b['region']??null; $city=$b['city']??null; $lat=isset($b['lat'])?floatval($b['lat']):null; $lon=isset($b['lon'])?floatval($b['lon']):null; $org=$b['org']??null; $vpn=isset($b['vpn'])?(int)!!$b['vpn']:null; $proxy=isset($b['proxy'])?(int)!!$b['proxy']:null; $tor=isset($b['tor'])?(int)!!$b['tor']:null; $hb=!empty($b['heartbeat']);

try{
  $pdo=getPDO();
  $stmt=$pdo->prepare('SELECT id FROM visits WHERE ip=? AND (device_id=? OR ? IS NULL) AND ts>=DATE_SUB(NOW(), INTERVAL 5 MINUTE) ORDER BY id DESC LIMIT 1');
  $stmt->execute([$ip,$dev,$dev]); $row=$stmt->fetch();
  if($row){ $id=$row['id']; $q='UPDATE visits SET user_agent=COALESCE(user_agent,?), country=COALESCE(?,country), region=COALESCE(?,region), city=COALESCE(?,city), lat=COALESCE(?,lat), lon=COALESCE(?,lon), org=COALESCE(?,org), vpn=COALESCE(?,vpn), proxy=COALESCE(?,proxy), tor=COALESCE(?,tor), last_seen=? WHERE id=?'; $pdo->prepare($q)->execute([$ua,$country,$region,$city,$lat,$lon,$org,$vpn,$proxy,$tor,now_lisbon(),$id]); }
  else{ $q='INSERT INTO visits (ip,user_agent,ts,blocked,notes,device_id,country,region,city,lat,lon,org,vpn,proxy,tor,last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'; $pdo->prepare($q)->execute([$ip,$ua,now_lisbon(),0,'tracked',$dev,$country,$region,$city,$lat,$lon,$org,$vpn,$proxy,$tor,now_lisbon()]); $id=$pdo->lastInsertId(); }
  if($hb && !empty($id)){ $pdo->prepare('UPDATE visits SET last_seen=? WHERE id=?')->execute([now_lisbon(),$id]); }
  $blocked = is_ip_blocked($ip) || is_device_blocked($dev);
  echo json_encode(['ok'=>true,'blocked'=>$blocked,'visit_id'=>$id]);
}catch(Exception $e){ http_response_code(200); echo json_encode(['ok'=>false,'error'=>'db','message'=>$e->getMessage()]); }
