<?php
session_start();
require_once __DIR__ . '/db.php';

// Exigir sessão do EyeWeb (credenciais dinâmicas) tal como o admin original
if (!isset($_SESSION['user'])) {
  header('Location: /login.php');
  exit();
}

// Timeout de inatividade igual ao EyeWeb
$tempoInativo = 600;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $tempoInativo)) {
  session_unset();
  session_destroy();
  header('Location: /login.php');
  exit();
}
$_SESSION['last_activity'] = time();

// actions (bloquear/desbloquear dispositivo)
if(isset($_GET['action']) && isset($_GET['device_id'])){
  $did = $_GET['device_id']; $pdo=getPDO(); ensure_schema();
  if($_GET['action']==='block'){
    $pdo->prepare('REPLACE INTO blocked_devices (device_id, blocked_at, reason) VALUES (?, NOW(), ?)')->execute([$did, $_GET['reason']??'blocked-by-admin']);
    $pdo->prepare('UPDATE visits SET blocked=1 WHERE device_id=?')->execute([$did]);
  }elseif($_GET['action']==='unblock'){
    $pdo->prepare('DELETE FROM blocked_devices WHERE device_id=?')->execute([$did]);
    $pdo->prepare('UPDATE visits SET blocked=0 WHERE device_id=?')->execute([$did]);
  }
  header('Location: admin.php'); exit;
}

ensure_schema(); $pdo=getPDO();
$rows = $pdo->query("SELECT MAX(v.id) id, v.device_id, MAX(v.ip) ip, (SUM(v.blocked)>0) blocked,
  GROUP_CONCAT(DISTINCT v.user_agent SEPARATOR ' | ') uas,
  MAX(v.country) country, MAX(v.region) region, MAX(v.city) city, MAX(v.org) org,
  MAX(v.vpn) vpn, MAX(v.proxy) proxy, MAX(v.tor) tor,
  MAX(v.ts) last_ts, MAX(v.last_seen) last_seen
  FROM visits v WHERE v.device_id IS NOT NULL GROUP BY v.device_id
  ORDER BY COALESCE(MAX(v.last_seen), MAX(v.ts)) DESC LIMIT 300")->fetchAll();

?><!doctype html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>EyeWeb - Segurança</title>
  <link rel="stylesheet" href="/css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>table{border-collapse:collapse;width:100%}td,th{border:1px solid #1f2937;padding:8px;font-family:Inter, Arial, sans-serif;font-size:13px}th{background:#0b1220}</style>
</head>
<body class="dark">

 <nav class="navbar">
  <a href="/admin.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
  <a href="/admin.php" class="nav-link">Add Data</a>
  <a href="/admin_data_base.php" class="nav-link">View Data</a>
  <a href="/defense.php" class="nav-link">Defesas</a>
     <a class="nav-icon" id="user-icon" title="Perfil"><i class="fa-solid fa-user"></i></a>
     <div id="user-popup" class="user-popup hide">
       <p>User: Admin</p>
  <a href="/logout.php" title="Sair"><i class="fa-solid fa-right-from-bracket logout-icon"></i></a>
     </div>
   </div>
 </nav>

  <header class="header container">
    <h1>Segurança — Dispositivos e Acessos</h1>
  </header>

  <main class="container">
  <div class="card" style="padding:12px;">
  <table>
    <thead><tr><th>ID</th><th>Dispositivo</th><th>IP</th><th>Localização</th><th>Org</th><th>VPN/Proxy</th><th>Online</th><th>Blocked</th><th>Última atividade</th><th>Ações</th></tr></thead>
    <tbody>
<?php foreach($rows as $r): $ua=''; if(!empty($r['uas'])){ $parts=explode(' | ',$r['uas']); $ua=trim($parts[0]); }
  $isBlocked=(bool)$r['blocked']; $loc=trim(($r['city']? $r['city'].' · ': '') . ($r['region']? $r['region'].' · ': '') . ($r['country']??''));
  $vpnStr = ($r['vpn']?'VPN ':'') . ($r['proxy']?'Proxy ':'') . ($r['tor']?'Tor ':'');
  $online = !empty($r['last_seen']) && (strtotime($r['last_seen']) >= time()-60);
?>
  <tr>
    <td><?= htmlspecialchars($r['id']) ?></td>
    <td><?php $type='Desconhecido'; if(stripos($ua,'iphone')!==false)$type='iPhone'; elseif(stripos($ua,'ipad')!==false)$type='iPad'; elseif(stripos($ua,'android')!==false && stripos($ua,'mobile')!==false)$type='Android (Telemóvel)'; elseif(stripos($ua,'android')!==false)$type='Android (Tablet)'; elseif(stripos($ua,'windows')!==false)$type='Windows'; elseif(stripos($ua,'mac os x')!==false||stripos($ua,'macintosh')!==false)$type='macOS'; elseif(stripos($ua,'linux')!==false)$type='Linux'; echo htmlspecialchars($type.' · '.($r['device_id']?:'—')); ?></td>
    <td><?= htmlspecialchars($r['ip']) ?></td>
    <td><?= htmlspecialchars($loc ?: '—') ?></td>
    <td><?= htmlspecialchars($r['org'] ?: '—') ?></td>
    <td><?= $vpnStr ? htmlspecialchars(trim($vpnStr)) : '—' ?></td>
    <td><?= $online ? '<span style="color:green">online</span>' : 'offline' ?></td>
    <td><?= $isBlocked ? 'Sim' : 'Não' ?></td>
    <td><?= htmlspecialchars($r['last_seen'] ?: $r['last_ts']) ?></td>
    <td><?php if(!$isBlocked): ?><a href="?action=block&device_id=<?= urlencode($r['device_id']) ?>">Bloquear</a><?php else: ?><a href="?action=unblock&device_id=<?= urlencode($r['device_id']) ?>">Desbloquear</a><?php endif; ?></td>
  </tr>
<?php endforeach; ?>
    </tbody></table>
  </div>
  </main>

<script>
// Popup do utilizador (igual ao resto do site)
document.addEventListener('click', (e) => {
  const el = e.target;
  if (el.matches('#user-icon') || el.closest('#user-icon')) {
    const p = document.getElementById('user-popup');
    if (p) p.classList.toggle('hide');
  }
});
</script>

<!-- Ensure admin chat bubble without external CSS (InfinityFree CORS-safe) -->
<script>
  try { sessionStorage.setItem('eyeSeen','true'); } catch(e) {}
</script>
<script>
  // Fallback loader: if chat script didn’t initialize, reload it via PHP (bypasses 403 on static .js)
  setTimeout(function(){
    try{
      if (!window.__EW_AGENT_CHAT_READY){
        var s=document.createElement('script');
        s.src = '/api/widget_js.php?v=' + Date.now();
        document.body.appendChild(s);
      }
    }catch(e){}
  }, 600);
</script>
<script>
  // Use remote relay to avoid host blocking
  window.AGENT_RELAY_URL = 'https://relay-g4bv.onrender.com/chat';
</script>
<script src="/api/widget_js.php"></script>

</body></html>
