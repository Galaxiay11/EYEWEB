<?php
// Config unificado para EyeWeb (usar InfinityFree hostname)
return [
  'db_host' => 'sql308.infinityfree.com',
  'db_port' => 3306,
  'db_name' => 'if0_40219866_eyeweb',
  'db_user' => 'if0_40219866',
  'db_pass' => 'l52cqwjHbJmG3UW', // INSERIR AQUI a password do MySQL do InfinityFree
  'admin_password' => getenv('ADMIN_PASS') ?: 'admin123',
  'display_db_errors' => getenv('DISPLAY_DB_ERRORS') === '1',
  // Token para endpoints públicos consumidos pelo agente (NÃO partilhar). Ideal definir via variável de ambiente AGENT_PUBLIC_TOKEN.
  // Se ficar vazio, os endpoints negam acesso.
  'agent_token' => getenv('AGENT_PUBLIC_TOKEN') ?: 'efc0014e0d36f09107633c42b456e453731fcfc6c4189b6932b5a63568f0e279',
];
