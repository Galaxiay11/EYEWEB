<?php
require __DIR__ . '/db.php'; $cfg = require __DIR__ . '/config.php'; header('Content-Type: text/plain; charset=utf-8');
try{
  echo "Config (sem password):\n";
  echo "- host: ".$cfg['db_host']."\n";
  echo "- port: ".$cfg['db_port']."\n";
  echo "- db:   ".$cfg['db_name']."\n";
  echo "- user: ".$cfg['db_user']."\n\n";
  $pdo=getPDO(); echo "Conexão OK\n"; $ver=$pdo->query('SELECT VERSION()')->fetchColumn(); echo "MySQL VERSION: $ver\n";
  // Garantir schema base
  try { ensure_schema(); echo "Schema criado/validado.\n"; } catch (Throwable $e) { echo "Falha ao criar schema: ".$e->getMessage()."\n"; }
  $pdo->query('SELECT 1 FROM visits LIMIT 0'); echo "Tabela visits OK\n";
}catch(Exception $e){ echo "Erro ao ligar à BD: ".$e->getMessage()."\n"; }
