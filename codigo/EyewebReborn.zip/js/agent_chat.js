// Simple embedded chat wiring for the agent with floating bubble toggle
(() => {
  // Inject minimal styles inline to avoid host 403/CORS on external CSS
  function ensureChatStyles(){
    const STYLE_ID = 'agent-chat-inline-styles';
    if (document.getElementById(STYLE_ID)) return;
    const css = `
    .agent-chat-container{position:fixed;right:20px;bottom:20px;width:360px;max-width:calc(100% - 40px);background:var(--card,#161b22);border:1px solid #222;border-radius:10px;color:var(--white,#c9d1d9);box-shadow:0 0 10px rgba(0,0,0,.5);z-index:2147482999;font-family:inherit;transition:transform .15s ease,opacity .15s ease;transform:translateY(6px);opacity:0}
    .agent-chat-container.open{transform:translateY(0);opacity:1}
    .agent-chat-header{padding:10px 12px;border-bottom:1px solid #222;display:flex;align-items:center;justify-content:space-between}
    .agent-chat-body{padding:10px;height:280px;overflow-y:auto;background:var(--bg,#0d1117);border-bottom-left-radius:10px;border-bottom-right-radius:10px}
    .agent-chat-footer{padding:10px;border-top:1px solid #222;display:flex;gap:8px;background:var(--card,#161b22);border-bottom-left-radius:10px;border-bottom-right-radius:10px}
    .agent-chat-input{flex:1;padding:10px 12px;background:var(--bg,#0d1117);border:1px solid var(--gray,#8b949e);color:var(--white,#c9d1d9);border-radius:6px}
    .agent-chat-send{background:var(--blue,#ff0000);border:none;color:#fff;padding:10px 12px;border-radius:6px}
    .agent-chat-toggle{cursor:pointer;color:var(--gray,#8b949e)}
    .agent-chat-bubble{position:fixed;right:20px;bottom:20px;width:56px;height:56px;border-radius:50%;background:var(--blue,#ff0000);border:1px solid rgba(0,0,0,.2);box-shadow:0 0 10px rgba(0,0,0,.5);color:#fff;font-size:20px;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:2147483000}
    .agent-chat-bubble.hidden{display:none}
    @media (max-width:520px){.agent-chat-container{left:10px;right:10px;bottom:80px;width:auto;max-width:none}.agent-chat-bubble{right:20px;bottom:20px}}
    .typing-indicator{display:flex;gap:6px;align-items:center;padding:6px 0}
    .typing-indicator .dot{width:8px;height:8px;border-radius:50%;background:var(--gray,#8b949e);opacity:.7;animation:typing-blink 1.2s infinite ease-in-out}
    .typing-indicator .dot:nth-child(2){animation-delay:.2s}
    .typing-indicator .dot:nth-child(3){animation-delay:.4s}
    @keyframes typing-blink{0%,80%,100%{transform:scale(.8);opacity:.4}40%{transform:scale(1);opacity:1}}
    .agent-msg-user{color:var(--blue,#ff0000)} .agent-msg-ia{color:var(--white,#c9d1d9)}
    `;
    const st = document.createElement('style'); st.id = STYLE_ID; st.type = 'text/css'; st.appendChild(document.createTextNode(css));
    document.head.appendChild(st);
  }

  ensureChatStyles();
  function qs(id){ return document.getElementById(id); }

  function createChatPanel(){
    const container = document.createElement('div');
    container.className = 'agent-chat-container';
    container.innerHTML = `
      <div class="agent-chat-header">
        <div><b>EyeWeb Agent</b></div>
        <div class="agent-chat-toggle" id="agentToggle" title="Fechar">✕</div>
      </div>
      <div class="agent-chat-body" id="agentChatbox"><p class="agent-msg-ia initial">IA: Como posso ajudar?</p></div>
      <div class="agent-chat-footer">
        <input id="agentPrompt" class="agent-chat-input" placeholder="Escreva sua pergunta..." aria-label="Mensagem" />
        <button id="agentSend" class="agent-chat-send">Enviar</button>
      </div>
    `;
    // start hidden; bubble will control visibility
    container.style.display = 'none';
    document.body.appendChild(container);
    return container;
  }

  function createBubble(){
    const b = document.createElement('button');
    b.id = 'agentBubble';
    b.className = 'agent-chat-bubble';
    b.type = 'button';
    b.title = 'Abrir chat';
    b.innerHTML = `<span class="agent-bubble-icon">💬</span>`;
    document.body.appendChild(b);
    return b;
  }

  const panel = createChatPanel();
  const bubble = createBubble();
  // Admin pages are the only ones that include this script; show bubble immediately
  bubble.classList.remove('hidden');
  bubble.style.display = 'flex';

  function showBubbleWhenReady(){
    // Ensure bubble remains visible even if other code toggles classes
    bubble.classList.remove('hidden');
    bubble.style.display = 'flex';
  }

  // Extra safety: on load, force show
  window.addEventListener('load', () => {
    bubble.classList.remove('hidden');
    bubble.style.display = 'flex';
  });
    try { window.__EW_AGENT_CHAT_READY = false; } catch(e){}
    try { window.__EW_AGENT_CHAT_READY = true; } catch(e){}
  showBubbleWhenReady();
  const sendBtn = qs('agentSend');
  const promptEl = qs('agentPrompt');
  const chatbox = qs('agentChatbox');
  const toggle = qs('agentToggle');

  function appendMessage(sender, text, cls){
    const p = document.createElement('p');
    p.className = cls;
    p.innerHTML = `<b>${sender}:</b> ${escapeHtml(text).replace(/\n/g,'<br/>')}`;
    chatbox.appendChild(p);
    chatbox.scrollTop = chatbox.scrollHeight;
  }

  function showTyping(){
    const wrap = document.createElement('div');
    wrap.className = 'typing-indicator';
    wrap.innerHTML = '<span class="dot"></span><span class="dot"></span><span class="dot"></span>';
    chatbox.appendChild(wrap);
    chatbox.scrollTop = chatbox.scrollHeight;
    return wrap;
  }

  function escapeHtml(s){ return String(s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"}[c]; }); }
  
    function base64ToBlob(b64, contentType){
      try{
        const byteChars = atob(b64);
        const byteArrays = [];
        const sliceSize = 1024;
        for (let offset = 0; offset < byteChars.length; offset += sliceSize) {
          const slice = byteChars.slice(offset, offset + sliceSize);
          const byteNumbers = new Array(slice.length);
          for (let i = 0; i < slice.length; i++) { byteNumbers[i] = slice.charCodeAt(i); }
          byteArrays.push(new Uint8Array(byteNumbers));
        }
        return new Blob(byteArrays, { type: contentType || 'application/octet-stream' });
      }catch(e){ console.warn('[Agent] base64ToBlob failed', e); return new Blob([],{type:'application/octet-stream'}); }
    }
  
    function triggerDownload(filename, blob){
      try{
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = filename || 'download.txt';
        document.body.appendChild(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(url); a.remove(); }, 0);
      }catch(e){ console.warn('[Agent] triggerDownload failed', e); }
    }

  async function sendChat(){
    const prompt = promptEl.value.trim(); if(!prompt) return;
    // Fire and forget ensure (do not await to avoid UI delay)
  try { fetch('/api/ensure_agent.php', { method: 'GET' }); } catch(_e) {}
    appendMessage('Você', prompt, 'agent-msg-user'); promptEl.value='';
    const typingEl = showTyping();
    const startedAt = Date.now();
    try{
    const payload = { q: prompt };
  let res;
  console.log('[Agent] Sending payload to /api/ai_answer.php via GET (query param)', payload);
  // Use GET with a benign param name to avoid host WAF keyword filters
  const url = '/api/ai_answer.php?q=' + encodeURIComponent(prompt);
  // Do not add custom headers to minimize preflight/WAF triggers
  res = await fetch(url, { method: 'GET' });
      // If the first call fails to reach agent quickly, retry up to 2x with a small backoff
      for (let i=0; i<2 && (!res || !res.ok); i++) {
        await new Promise(r=>setTimeout(r, 300 + i*200));
  const url2 = '/api/ai_answer.php?q=' + encodeURIComponent(prompt) + '&t=' + Date.now();
  res = await fetch(url2, { method: 'GET' });
      }
      let j = null;
      try { j = await res.json(); } catch(errJson){
        const text = await res.text().catch(()=>null);
        console.error('[Agent] failed to parse JSON response', errJson, text);
        throw new Error(text || 'Non-JSON response from proxy');
      }
      console.log('[Agent] response', res.status, j);
      // Ensure typing is visible at least 1s
      const elapsed = Date.now() - startedAt;
      if (elapsed < 1000) await new Promise(r=>setTimeout(r, 1000 - elapsed));
      if (typingEl && typingEl.parentNode) typingEl.parentNode.removeChild(typingEl);
      if (!res.ok) {
        appendMessage('IA', j.error || j.detail || ('Erro do agente: ' + (j.message || res.status)), 'agent-msg-ia');
      } else {
        appendMessage('IA', j.answer || (j.detail || 'Erro na resposta'), 'agent-msg-ia');
        // Auto-download any attachments (e.g., generated report)
        if (j.attachments && Array.isArray(j.attachments)){
          j.attachments.forEach(att => {
            try{
              if (!att || !att.content_base64) return;
              const blob = base64ToBlob(att.content_base64, att.content_type || 'application/octet-stream');
              triggerDownload(att.filename || 'download.dat', blob);
            }catch(e){ console.warn('[Agent] attachment download failed', e); }
          });
        }
      }
    }catch(e){
      console.error('[Agent] sendChat error', e);
      const elapsed = Date.now() - startedAt;
      if (elapsed < 1000) await new Promise(r=>setTimeout(r, 1000 - elapsed));
      if (typingEl && typingEl.parentNode) typingEl.parentNode.removeChild(typingEl);
      appendMessage('IA', 'Erro ao contactar agente: ' + (e.message || e), 'agent-msg-ia');
    }
  }

  function openPanel(){
    panel.style.display = 'block';
    // small timeout to allow CSS transition if used
    requestAnimationFrame(()=> panel.classList.add('open'));
    bubble.classList.add('hidden');
    // focus input
    setTimeout(()=> promptEl.focus(), 150);
    // mark timestamp for just-opened guard
    panel.dataset.openedAt = String(Date.now());
    // Fire and forget ensure agent
  try { fetch('/api/ensure_agent.php', { method: 'GET' }); } catch(_e) {}
  }

  function closePanel(){
    panel.classList.remove('open');
    // after transition, hide
    setTimeout(()=>{ panel.style.display = 'none'; }, 180);
    bubble.classList.remove('hidden');
  }

  // Prevent spam clicks: brief disable after each click
  let bubbleLocked = false;
  // Stop click propagation to avoid document listener closing panel immediately
  bubble.addEventListener('click', (ev)=>{
    ev.stopPropagation();
    if (bubbleLocked) return;
    bubbleLocked = true;
    bubble.setAttribute('aria-disabled','true');
    bubble.style.pointerEvents = 'none';
    setTimeout(()=>{ bubbleLocked = false; bubble.removeAttribute('aria-disabled'); bubble.style.pointerEvents = ''; }, 1000);
    if(panel.style.display === 'block') closePanel(); else openPanel();
  });

  toggle.addEventListener('click', (ev)=>{ ev.stopPropagation(); closePanel(); });
  // Prevent clicks inside the panel from bubbling to document
  panel.addEventListener('click', (ev)=> ev.stopPropagation());
  sendBtn.addEventListener('click', sendChat);
  promptEl.addEventListener('keydown', (e)=>{ if(e.key==='Enter'){ e.preventDefault(); sendChat(); } });

  // allow clicking outside panel to close (optional)
  document.addEventListener('click', (e)=>{
    if(panel.style.display !== 'block') return;
    if(e.target === bubble || panel.contains(e.target)) return;
    // Guard: if panel was just opened (< 200ms), ignore this outside click
    const openedAt = Number(panel.dataset.openedAt || 0);
    if (Date.now() - openedAt < 200) return;
    closePanel();
  });
})();
