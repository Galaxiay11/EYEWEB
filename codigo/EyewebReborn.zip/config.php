<?php
// Configuração de credenciais temporárias baseadas em tempo (sem BD)
// IMPORTANTE: Altere este segredo antes de usar em produção.
// Pode ser qualquer string suficientemente longa e aleatória.
define('ADMIN_SECRET', 'CHANGE_ME___Va1dS3cr3t_L0ng_Random_Base');

// Prefixo do username gerado
define('ADMIN_USERNAME_PREFIX', 'admin');

// Tamanho da janela (segundos) para códigos temporários
define('ADMIN_STEP_SECONDS', 60); // 60s por passo

// Tolerância de passos (para compensar atraso de relógio). 1 = aceita passo atual e ±1
define('ADMIN_SKEW_STEPS', 1);

// Comprimentos gerados
define('ADMIN_USER_SUFFIX_LENGTH', 6);  // ex.: admin123456
define('ADMIN_PASSWORD_LENGTH', 20);     // ex.: 20 chars

// ========================
// AI Agent
define('AGENT_BASE_URL', 'https://agent-hxob.onrender.com');
define('AGENT_SHARED_SECRET', '7391d23b35ea7bc8642c16f132bafd8b6c2523973979f3fcf402d10f41eeda28');
// ========================

