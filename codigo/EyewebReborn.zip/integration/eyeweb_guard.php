<?php
// Wrapper para usar o guard raiz a partir da pasta EyeWeb
$root = dirname(__DIR__, 1); // EyeWeb/
$projectRoot = dirname($root); // raiz do projeto
if (file_exists($projectRoot . '/db.php')) require_once $projectRoot . '/db.php';
if (file_exists($projectRoot . '/integration/eyeweb_guard.php')) require_once $projectRoot . '/integration/eyeweb_guard.php';
