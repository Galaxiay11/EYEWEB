// EyeWeb tracker: cria device_id (se faltar), envia visita e heartbeats para /api/track.php
(function(){
  function randId(){ try{ return 'd_'+Array.from(crypto.getRandomValues(new Uint8Array(8))).map(b=>b.toString(16).padStart(2,'0')).join('')+'_'+Date.now().toString(16); }catch(e){ return 'd_'+Math.random().toString(16).slice(2)+'_'+Date.now().toString(16);} }
  function getCookie(n){ return document.cookie.split('; ').reduce((a,c)=>{const [k,...v]=c.split('='); a[k]=v.join('='); return a;}, {})[n]; }
  function setCookie(n,v,days){ var d=new Date(); d.setTime(d.getTime()+days*24*60*60*1000); document.cookie=n+'='+v+'; expires='+d.toUTCString()+'; path=/; samesite=Lax'; }
  var deviceId = getCookie('device_id');
  if(!deviceId){ deviceId = randId(); setCookie('device_id', deviceId, 365); }

  async function postJSON(url, data){
    try{
      await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
    }catch(e){ /* ignore network errors */ }
  }

  // Try to enrich with approximate location and network info (no permissions required)
  let lastGeo = null;
  // Post immediately so the visit appears even before geo is ready
  try { postJSON('/api/track.php', { device_id: deviceId }); } catch(e){}
  (async function(){
    let payload = { device_id: deviceId };
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 1500);
      const res = await fetch('https://ipwho.is/', { signal: ctrl.signal });
      clearTimeout(t);
      if (res && res.ok) {
        const j = await res.json();
        if (j && j.success !== false) {
          if (j.country) payload.country = j.country;
          if (j.region) payload.region = j.region;
          if (j.city) payload.city = j.city;
          if (j.latitude) payload.lat = j.latitude;
          if (j.longitude) payload.lon = j.longitude;
          if (j.connection && (j.connection.org || j.connection.isp)) {
            payload.org = j.connection.org || j.connection.isp;
          }
          if (j.security) {
            if (typeof j.security.vpn === 'boolean') payload.vpn = j.security.vpn;
            if (typeof j.security.proxy === 'boolean') payload.proxy = j.security.proxy;
            if (typeof j.security.tor === 'boolean') payload.tor = j.security.tor;
          }
          lastGeo = {
            country: payload.country,
            region: payload.region,
            city: payload.city,
            lat: payload.lat,
            lon: payload.lon,
            org: payload.org,
            vpn: payload.vpn,
            proxy: payload.proxy,
            tor: payload.tor
          };
        }
      }
    } catch(e) { /* ignore geo errors */ }
    postJSON('/api/track.php', payload);
  })();
  // Heartbeat every 20s
  setInterval(function(){
    const hb = { device_id: deviceId, heartbeat: true };
    if (lastGeo) {
      hb.country = lastGeo.country;
      hb.region = lastGeo.region;
      hb.city = lastGeo.city;
      hb.lat = lastGeo.lat;
      hb.lon = lastGeo.lon;
      hb.org = lastGeo.org;
      hb.vpn = lastGeo.vpn;
      hb.proxy = lastGeo.proxy;
      hb.tor = lastGeo.tor;
    }
    postJSON('/api/track.php', hb);
  }, 20000);
})();
