<?php
require_once __DIR__ . '/inc/defense_bootstrap.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION['user'])) {
  header('Location: login.php');
  exit();
}

$tempoInativo = 600;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $tempoInativo)) {
  session_unset();
  session_destroy();
  header('Location: login.php');
  exit();
}
$_SESSION['last_activity'] = time();

// SSR fallback: obter dispositivo/acessos no servidor para render inicial
require_once __DIR__ . '/security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$__devices = [];
try {
  $pdo = getPDO();
  $sql = "SELECT MAX(v.id) AS id,
                 v.device_id,
                 MAX(v.ip) AS ip,
                 (SUM(v.blocked)>0) AS blocked,
                 GROUP_CONCAT(DISTINCT v.user_agent SEPARATOR ' | ') AS uas,
                 MAX(v.country) AS country,
                 MAX(v.region) AS region,
                 MAX(v.city) AS city,
                 MAX(v.org) AS org,
                 MAX(v.vpn) AS vpn,
                 MAX(v.proxy) AS proxy,
                 MAX(v.tor) AS tor,
                 MAX(v.ts) AS last_ts,
                 MAX(v.last_seen) AS last_seen
          FROM visits v
          WHERE v.device_id IS NOT NULL
          GROUP BY v.device_id
          ORDER BY COALESCE(MAX(v.last_seen), MAX(v.ts)) DESC
          LIMIT 300";
  $rs = $pdo->query($sql);
  while ($r = $rs->fetch(PDO::FETCH_ASSOC)) {
    $ua = '';
    if (!empty($r['uas'])) { $parts = explode(' | ', $r['uas']); $ua = trim($parts[0]); }
    $type = 'Desconhecido';
    $ual = strtolower($ua);
    if (strpos($ual,'iphone')!==false) $type='iPhone';
    elseif (strpos($ual,'ipad')!==false) $type='iPad';
    elseif (strpos($ual,'android')!==false && strpos($ual,'mobile')!==false) $type='Android (Telemóvel)';
    elseif (strpos($ual,'android')!==false) $type='Android (Tablet)';
    elseif (strpos($ual,'windows')!==false) $type='Windows';
    elseif (strpos($ual,'mac os x')!==false || strpos($ual,'macintosh')!==false) $type='macOS';
    elseif (strpos($ual,'linux')!==false) $type='Linux';
    $loc = trim(($r['city']? $r['city'].' · ' : '') . ($r['region']? $r['region'].' · ' : '') . ($r['country']??''));
    $vpnStr = (($r['vpn']?'VPN ':'') . ($r['proxy']?'Proxy ':'') . ($r['tor']?'Tor ':''));
    $online = !empty($r['last_seen']) && (strtotime($r['last_seen']) >= time()-60);
    $__devices[] = [
      'id' => (int)$r['id'],
      'device_id' => $r['device_id'],
      'device_type' => $type,
      'ip' => $r['ip'],
      'location' => $loc,
      'org' => $r['org'],
      'vpn_proxy' => trim($vpnStr),
      'online' => $online,
      'blocked' => (bool)$r['blocked'],
      'last' => $r['last_seen'] ?: $r['last_ts'],
    ];
  }
} catch (Throwable $e) { $__devices = []; }

?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>EyeWeb - Defense</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="css/defense.css">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">

 <nav class="navbar">
   <a href="admin.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
    <a href="admin.php" class="nav-link">Add Data</a>
    <a href="admin_data_base.php" class="nav-link">View Data</a>
    <a href="defense.php" class="nav-link active">Defesas</a>

    <a class="nav-icon" id="user-icon" title="Login">
      <i class="fa-solid fa-user"></i>
    </a>

    <div id="user-popup" class="user-popup hide">
      <p>User: Admin</p>
      <a href="logout.php" title="Sair">
        <i class="fa-solid fa-right-from-bracket logout-icon"></i>
      </a>
    </div>
   </div>
 </nav>

  <header class="header container">
    <h1>Painel de supervisão e segurança</h1>
  </header>

  <main class="container wide">
    <nav class="def-subnav" role="navigation" aria-label="Defense subnav">
      <ul>
        <li class="subnav-item active" data-tab="devices">Dispositivos e Acessos</li>
        <li class="subnav-item" data-tab="attacks">Ataques Bloqueados</li>
      </ul>
    </nav>

    <div class="defense-grid">
      <section id="sec-devices" class="def-card table-card" data-section data-tab="devices">
        <div class="card-body">
          <div class="conn-active-row" style="display:flex; gap:12px; align-items:flex-start;">
            <div class="conn-table-wrapper" style="flex:1;">
              <table class="conn-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Dispositivo</th>
                    <th>IP</th>
                    <th>Localização</th>
                    <th>VPN/Proxy</th>
                    <th>Online</th>
                    <th>Blocked</th>
                    <th>Última atividade</th>
                    <th>Ações</th>
                  </tr>
                </thead>
                <tbody id="devices-tbody">
                <?php if (!empty($__devices)):
                  foreach($__devices as $r): $online = $r['online'] ? '<span style="color:green">online</span>' : 'offline'; $blocked = $r['blocked'] ? 'Sim' : 'Não'; $devLabel = htmlspecialchars(($r['device_type'] ?? '—'));
                ?>
                  <tr>
                    <td><?= (int)$r['id'] ?></td>
                    <td><?= $devLabel ?></td>
                    <td><?= htmlspecialchars($r['ip'] ?? '') ?></td>
                    <td><?= htmlspecialchars($r['location'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($r['vpn_proxy'] ?? '—') ?></td>
                    <td><?= $online ?></td>
                    <td><?= $blocked ?></td>
                    <td><?= htmlspecialchars($r['last'] ?? '') ?></td>
                    <td class="action-icons">
                      <?php if ($r['blocked']): ?>
                        <button class="icon-btn btn-toggle unblock-state" data-id="<?= htmlspecialchars($r['device_id'] ?? '') ?>" data-blocked="1" title="Desbloquear">
                          <i class="fa-solid fa-unlock"></i>
                          <span style="margin-left:6px;">Desbloquear</span>
                        </button>
                      <?php else: ?>
                        <button class="icon-btn btn-toggle block-state" data-id="<?= htmlspecialchars($r['device_id'] ?? '') ?>" data-blocked="0" title="Bloquear">
                          <i class="fa-solid fa-ban"></i>
                          <span style="margin-left:6px;">Bloquear</span>
                        </button>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; endif; ?>
                </tbody>
              </table>
            </div>
            <div class="conn-side-actions" style="min-width:110px; display:flex; flex-direction:column; align-items:center; gap:8px;">
              <button id="btn-refresh-devices" class="icon-btn" style="background:#b91c1c;color:#fff;padding:8px 12px;border-radius:6px;">Refresh</button>
            </div>
          </div>
        </div>
      </section>

      <section id="sec-attacks" class="def-card table-card hidden" data-section data-tab="attacks">
        <div class="card-body">
          <div class="ddos-stats" style="display:flex;gap:12px;align-items:center;margin-bottom:8px;flex-wrap:wrap;">
            <div style="background:#1f242c;border:1px solid rgba(255,255,255,0.06);border-radius:8px;padding:8px 12px;display:flex;align-items:center;gap:8px;">
              <span style="color:#9ca3af;">Pedidos (10s):</span>
              <strong id="ddos-total" style="font-size:1.1rem;">0</strong>
            </div>
            <div id="ddos-top" style="display:flex;gap:8px;flex-wrap:wrap;"></div>
          </div>
          <div class="conn-table-wrapper">
            <table class="conn-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Data</th>
                  <th>IP</th>
                  <th>Método</th>
                  <th>Caminho</th>
                  <th>Regra</th>
                  <th>Razão</th>
                </tr>
              </thead>
              <tbody id="attacks-tbody"></tbody>
            </table>
          </div>
        </div>
      </section>
    </div>

  </main>

  <!-- Modal de confirmação para desbloquear IP -->
  <div id="confirm-modal" class="modal hidden" aria-hidden="true" role="dialog" aria-modal="true" style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.5);z-index:9999;">
    <div class="modal-content" style="background:#1f2937;color:#fff;padding:20px 24px;border-radius:8px;min-width:320px;max-width:90%;box-shadow:0 10px 25px rgba(0,0,0,.4);">
      <h3 style="margin:0 0 10px 0;">Tem mesmo a certeza que deseja desbloquear este IP?</h3>
      <p id="confirm-ip" style="opacity:.9;margin:0 0 16px 0;"></p>
      <div style="display:flex;gap:10px;justify-content:flex-end;">
        <button id="confirm-no" class="icon-btn" style="background:#374151;color:#fff;padding:8px 12px;border-radius:6px;">Não</button>
        <button id="confirm-yes" class="icon-btn" style="background:#b91c1c;color:#fff;padding:8px 12px;border-radius:6px;">Sim</button>
      </div>
    </div>
  </div>

  <script>
  (function(){
    // tabs behavior
    const tabs = document.querySelectorAll('.def-subnav .subnav-item');
    const sections = document.querySelectorAll('[data-section]');
    tabs.forEach(t => t.addEventListener('click', ()=>{
      tabs.forEach(x => x.classList.remove('active'));
      t.classList.add('active');
      const sel = t.getAttribute('data-tab');
      sections.forEach(s => {
        if (s.getAttribute('data-tab') === sel) s.classList.remove('hidden');
        else s.classList.add('hidden');
      });
    }));
    // user popup toggle
    document.addEventListener('click', (e) => {
      const el = e.target;
      if (el.matches('#user-icon') || el.closest('#user-icon')) {
        const up = document.getElementById('user-popup');
        if (up) up.classList.toggle('hide');
      }
    });

    async function fetchJSON(url, opts){
      const res = await fetch(url, Object.assign({ credentials: 'same-origin' }, opts||{}));
      if (!res.ok) throw new Error('HTTP '+res.status);
      return res.json();
    }

  const tbody = document.getElementById('devices-tbody');
    function deviceRow(r){
      const online = r.online ? '<span style="color:green">online</span>' : 'offline';
      const blocked = r.blocked ? 'Sim' : 'Não';
      const actions = r.blocked
        ? `<button class="icon-btn btn-toggle unblock-state" data-id="${r.device_id}" data-blocked="1" title="Desbloquear"><i class="fa-solid fa-unlock"></i><span style="margin-left:6px;">Desbloquear</span></button>`
        : `<button class="icon-btn btn-toggle block-state" data-id="${r.device_id}" data-blocked="0" title="Bloquear"><i class="fa-solid fa-ban"></i><span style="margin-left:6px;">Bloquear</span></button>`;
      const devLabel = `${r.device_type}`;
      return `<tr>
        <td>${r.id}</td>
        <td>${devLabel}</td>
        <td>${r.ip || ''}</td>
        <td>${r.location || '—'}</td>
        <td>${r.vpn_proxy || '—'}</td>
        <td>${online}</td>
        <td>${blocked}</td>
        <td>${r.last || ''}</td>
        <td class="action-icons">${actions}</td>
      </tr>`;
    }

    async function refreshDevices(){
      try{
        const json = await fetchJSON('api/defense_data.php?type=devices');
        const data = json.data||[];
        // Merge client-side cached geo before rendering to avoid flicker
        for (const r of data){
          if ((!r.location || r.location === '—') && r.ip){
            const cached = geoCache.get(r.ip);
            if (cached) r.location = cached;
            else lookupIp(r.ip);
          }
        }
        const rows = data.map(deviceRow).join('');
        if (tbody) {
          tbody.innerHTML = rows || '<tr><td colspan="9">Sem dados</td></tr>';
        }
      }catch(e){ /* noop */ }
    }

    // Client-side IP geolocation cache and filler for missing locations
    const geoCache = new Map(); // ip -> 'City · Region · Country'
    const inFlight = new Set();
    async function lookupIp(ip){
      if (!ip || geoCache.has(ip) || inFlight.has(ip)) return;
      inFlight.add(ip);
      try{
        const ctrl = new AbortController();
        const t = setTimeout(()=>ctrl.abort(), 1500);
        const res = await fetch('https://ipwho.is/'+encodeURIComponent(ip), { signal: ctrl.signal });
        clearTimeout(t);
        if (res && res.ok){
          const j = await res.json();
          if (j && j.success !== false){
            const parts = [];
            if (j.city) parts.push(j.city);
            if (j.region) parts.push(j.region);
            if (j.country) parts.push(j.country);
            const txt = parts.length ? parts.join(' · ') : '—';
            geoCache.set(ip, txt);
          }
        }
      }catch(e){}
      finally{ inFlight.delete(ip); }
    }

    // No post-render patching to avoid flicker; we render with cached geo above

    // Attacks table
    const attacksBody = document.getElementById('attacks-tbody');
  const ddosTotal = document.getElementById('ddos-total');
  const ddosTop = document.getElementById('ddos-top');
    function attackRow(a){
      const when = a.time || '';
      const path = a.path || '';
      const rule = a.rule || '';
      const reason = (a.reason || rule || '').toString().slice(0,120).replace(/</g,'&lt;');
      return `<tr>
        <td>${a.id}</td>
        <td>${when}</td>
        <td>${a.ip || ''}</td>
        <td>${a.method || ''}</td>
        <td style="text-align:left">${path}</td>
        <td>${rule}</td>
        <td style=\"text-align:left\">${reason}</td>
      </tr>`;
    }
    async function refreshAttacks(){
      try{
        const json = await fetchJSON('api/defense_data.php?type=attacks');
        const rows = (json.data||[]).map(attackRow).join('');
        if (attacksBody) attacksBody.innerHTML = rows || '<tr><td colspan="7">Sem ataques</td></tr>';
      }catch(e){}
    }

    async function refreshDdos(){
      try{
        const json = await fetchJSON('api/defense_data.php?type=ddos_stats');
        const data = json.data || {};
        if (ddosTotal) ddosTotal.textContent = data.total10s || 0;
        if (ddosTop) {
          const items = (data.top||[]).map(x => {
            const c = x.count10s||0;
            const color = c >= 20 ? '#dc2626' : (c >= 10 ? '#f59e0b' : '#16a34a');
            return `<div style="background:#111827;border:1px solid rgba(255,255,255,0.06);border-radius:8px;padding:6px 10px;">
              <div style="font-size:.85rem;color:#9ca3af;">${x.ip}</div>
              <div style="font-weight:700;color:${color}">${c}/10s</div>
            </div>`;
          }).join('');
          ddosTop.innerHTML = items;
        }
      }catch(e){}
    }

  var btnRef = document.getElementById('btn-refresh-devices');
  if (btnRef) btnRef.addEventListener('click', async function(){
    try {
      await fetchJSON('api/clear_devices.php', { method:'POST' });
    } catch(e) {}
    await refreshDevices();
  });

    document.addEventListener('click', async (e) => {
      const btn = e.target.closest('.btn-toggle');
      if (!btn) return;
      e.preventDefault();
      const id = btn.dataset.id; if (!id) return;
  const row = btn.closest('tr');
  const blockedCell = row ? row.children[6] : null; // Após remover "Org", 7ª coluna = Blocked
      const isBlocked = btn.dataset.blocked === '1';
      btn.disabled = true;
      try{
        if (!isBlocked) {
          const body = new URLSearchParams(); body.append('device_id', id); body.append('reason','Bloqueio manual');
          await fetchJSON('api/block_device.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body });
          // UI -> estado bloqueado
          btn.dataset.blocked = '1';
          btn.classList.remove('block-state');
          btn.classList.add('unblock-state');
          btn.innerHTML = '<i class="fa-solid fa-unlock"></i><span style="margin-left:6px;">Desbloquear</span>';
          if (blockedCell) blockedCell.textContent = 'Sim';
        } else {
          const body = new URLSearchParams(); body.append('device_id', id);
          await fetchJSON('api/unblock_device.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body });
          // UI -> estado desbloqueado
          btn.dataset.blocked = '0';
          btn.classList.remove('unblock-state');
          btn.classList.add('block-state');
          btn.innerHTML = '<i class="fa-solid fa-ban"></i><span style="margin-left:6px;">Bloquear</span>';
          if (blockedCell) blockedCell.textContent = 'Não';
        }
      }catch(err){ /* opcional: mensagem de erro */ }
      finally{ btn.disabled = false; }
    });

    // primeira carga + intervalo curto (1s) para efeito "tempo real"
    refreshDevices();
    setInterval(refreshDevices, 1000);
    setInterval(refreshAttacks, 2000);
    setInterval(refreshDdos, 1000);
    refreshAttacks();
    refreshDdos();
  })();
  </script>
  <script>
    // In admin area, force the chat bubble to be shown immediately
    try { sessionStorage.setItem('eyeSeen','true'); } catch(e) {}
  </script>
  <script>
    // Fallback loader: if chat script didn’t initialize, reload it via PHP (bypasses 403 on static .js)
    setTimeout(function(){
      try{
        if (!window.__EW_AGENT_CHAT_READY){
          var s=document.createElement('script');
          s.src = '/api/widget_js.php?v=' + Date.now();
          document.body.appendChild(s);
        }
      }catch(e){}
    }, 600);
  </script>
  <script>
    // Use remote relay to avoid host blocking
    window.AGENT_RELAY_URL = 'https://relay-g4bv.onrender.com/chat';
  </script>
  <script src="/api/widget_js.php"></script>
</body>
</html>
