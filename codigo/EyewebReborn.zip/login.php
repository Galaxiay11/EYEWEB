<?php
require_once __DIR__ . '/inc/defense_bootstrap.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/config.php';

// Redireciona se já estiver autenticado
if (isset($_SESSION['user'])) {
  header('Location: /defense.php');
  exit();
}

// ==========================
// Credenciais baseadas em tempo (stateless)
// ==========================

function base32_encode_custom($data) {
  // Não precisamos especificamente de base32, mas deixo utilitário caso queira mudar o algoritmo
  return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function hmac_sha256($key, $msg) {
  return hash_hmac('sha256', $msg, $key, true);
}

function current_time_step($t = null) {
  if ($t === null) { $t = time(); }
  return (int) floor($t / ADMIN_STEP_SECONDS);
}

function derive_credentials_for_step($step) {
  // Deriva username e password a partir do passo temporal e segredo compartilhado
  $msg = 'admin-login|' . $step;
  $mac = hmac_sha256(ADMIN_SECRET, $msg);

  // Username: prefixo + 6 dígitos do primeiro int derivado
  $num = unpack('N', substr($mac, 0, 4))[1] & 0x7FFFFFFF; // positivo
  $suffix = str_pad((string)($num % pow(10, ADMIN_USER_SUFFIX_LENGTH)), ADMIN_USER_SUFFIX_LENGTH, '0', STR_PAD_LEFT);
  $username = ADMIN_USERNAME_PREFIX . $suffix;

  // Password: 20 chars a partir de um alfabeto seguro
  $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+[]{}<>?/.,~';
  $pwd = '';
  $macBytes = $mac . hmac_sha256(ADMIN_SECRET, 'admin-login-extend|' . $step);
  $len = strlen($alphabet);
  for ($i = 0; $i < ADMIN_PASSWORD_LENGTH; $i++) {
    $idx = ord($macBytes[$i % strlen($macBytes)]) % $len;
    $pwd .= $alphabet[$idx];
  }

  return [$username, $pwd];
}

function verify_credentials($user, $pass) {
  $nowStep = current_time_step();
  for ($offset = -ADMIN_SKEW_STEPS; $offset <= ADMIN_SKEW_STEPS; $offset++) {
    $step = $nowStep + $offset;
    [$u, $p] = derive_credentials_for_step($step);
    if (hash_equals($u, $user) && hash_equals($p, $pass)) {
      return true;
    }
  }
  return false;
}

// Processa o login se o formulário for enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'] ?? '';
  $password = $_POST['password'] ?? '';

  if (verify_credentials($username, $password)) {
    session_regenerate_id(true);
    $_SESSION['user'] = 'admin';
  header('Location: /defense.php');
    exit();
  } else {
    $error = 'Credenciais inválidas (ou expiradas).';
  }
}
?>



<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - EyeWeb</title>
  <link rel="stylesheet" href="css/login.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">
  <div class="login-container">
    <h1 class="login-title">Área Administrador</h1>

    <?php if (isset($error)) echo "<p style='color:#ff6b6b;margin-bottom:1rem;'>" . htmlspecialchars($error) . "</p>"; ?>

    <form class="login-form" method="post" action="">
      <label for="username">Usuário</label>
      <input type="text" id="username" name="username" required />

      <label for="password">Senha</label>
      <input type="password" id="password" name="password" required />

      <div class="button-row">
        <button type="submit">Entrar</button>
        <a href="index.php" class="back-button">Voltar</a>
      </div>
    </form>

  </div>
</body>
</html>
