<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['user'])) { http_response_code(401); echo json_encode(['error' => 'unauthorized']); exit; }

$ip = $_POST['ip'] ?? '';
$isVpn = isset($_POST['is_vpn']) ? (int)$_POST['is_vpn'] : null;
$provider = $_POST['provider'] ?? null;

if (!filter_var($ip, FILTER_VALIDATE_IP)) { http_response_code(400); echo json_encode(['error' => 'invalid_ip']); exit; }
if ($isVpn === null || ($isVpn !== 0 && $isVpn !== 1)) { http_response_code(400); echo json_encode(['error' => 'invalid_is_vpn']); exit; }

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();

$stmt = $pdo->prepare('REPLACE INTO vpn_cache (ip, is_vpn, provider) VALUES (?, ?, ?)');
$ok = $stmt->execute([$ip, $isVpn, $provider]);

echo json_encode(['ok' => (bool)$ok]);
