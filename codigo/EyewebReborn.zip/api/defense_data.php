<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user'])) {
  http_response_code(401);
  echo json_encode(['error' => 'unauthorized']);
  exit;
}

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();

$type = $_GET['type'] ?? 'active';

if ($type === 'devices') {
  // Aggregated devices/accesses, same logic as the old admin devices table
  $sql = "SELECT MAX(v.id) AS id,
                 v.device_id,
                 MAX(v.ip) AS ip,
                 (SUM(v.blocked)>0) AS blocked,
                 GROUP_CONCAT(DISTINCT v.user_agent SEPARATOR ' | ') AS uas,
                 MAX(v.country) AS country,
                 MAX(v.region) AS region,
                 MAX(v.city) AS city,
                 MAX(v.org) AS org,
                 MAX(v.vpn) AS vpn,
                 MAX(v.proxy) AS proxy,
                 MAX(v.tor) AS tor,
                 MAX(v.ts) AS last_ts,
                 MAX(v.last_seen) AS last_seen
          FROM visits v
          WHERE v.device_id IS NOT NULL
          GROUP BY v.device_id
          ORDER BY COALESCE(MAX(v.last_seen), MAX(v.ts)) DESC
          LIMIT 300";
  $rs = $pdo->query($sql);
  $rows = [];
  while ($r = $rs->fetch(PDO::FETCH_ASSOC)) {
    // Compute quick fields client-side ready
    $ua = '';
    if (!empty($r['uas'])) {
      $parts = explode(' | ', $r['uas']);
      $ua = trim($parts[0]);
    }
    $type = 'Desconhecido';
    $ual = strtolower($ua);
    if (strpos($ual,'iphone')!==false) $type='iPhone';
    elseif (strpos($ual,'ipad')!==false) $type='iPad';
    elseif (strpos($ual,'android')!==false && strpos($ual,'mobile')!==false) $type='Android (Telemóvel)';
    elseif (strpos($ual,'android')!==false) $type='Android (Tablet)';
    elseif (strpos($ual,'windows')!==false) $type='Windows';
    elseif (strpos($ual,'mac os x')!==false || strpos($ual,'macintosh')!==false) $type='macOS';
    elseif (strpos($ual,'linux')!==false) $type='Linux';
    $loc = trim(($r['city']? $r['city'].' · ' : '') . ($r['region']? $r['region'].' · ' : '') . ($r['country']??''));
    $vpnStr = (($r['vpn']?'VPN ':'') . ($r['proxy']?'Proxy ':'') . ($r['tor']?'Tor ':''));
    $online = !empty($r['last_seen']) && (strtotime($r['last_seen']) >= time()-60);
    $rows[] = [
      'id' => (int)$r['id'],
      'device_id' => $r['device_id'],
      'device_type' => $type,
      'ip' => $r['ip'],
      'location' => $loc,
      'org' => $r['org'],
      'vpn_proxy' => trim($vpnStr),
      'online' => (bool)$online,
      'blocked' => (bool)$r['blocked'],
      'last' => $r['last_seen'] ?: $r['last_ts'],
    ];
  }
  echo json_encode(['data' => $rows]);
  exit;
}

if ($type === 'attacks') {
  $rs = $pdo->query("SELECT id, ip, device_id, method, path, rule, snippet, detected_at, blocked_at, reason
                     FROM attacks
                     WHERE blocked = 1
                     ORDER BY detected_at DESC
                     LIMIT 300");
  $rows = [];
  while ($r = $rs->fetch(PDO::FETCH_ASSOC)) {
    $rows[] = [
      'id' => (int)$r['id'],
      'ip' => $r['ip'],
      'device_id' => $r['device_id'],
      'method' => $r['method'],
      'path' => $r['path'],
      'rule' => $r['rule'],
      'snippet' => $r['snippet'],
      'reason' => $r['reason'],
      'time' => $r['detected_at'],
      'blocked_at' => $r['blocked_at'],
    ];
  }
  echo json_encode(['data' => $rows]);
  exit;
}

if ($type === 'active') {
  $rs = $pdo->query("SELECT a.ip,
                             a.connections_5s,
                             (a.vpn_active+0) AS vpn_active,
                             a.packets_5s,
                             a.connections_total,
                             a.packet_type,
                             a.status,
                             a.last_seen
                      FROM active_connections a
                      LEFT JOIN blocked_ips b ON b.ip = a.ip
                      WHERE b.ip IS NULL
                      ORDER BY a.connections_5s DESC");
  $rows = [];
  while ($row = $rs->fetch(PDO::FETCH_ASSOC)) { $rows[] = $row; }
  echo json_encode(['data' => $rows]);
  exit;
}

if ($type === 'ddos_stats') {
  // Requests in last 10s: total and per-IP top list
  $total = (int)$pdo->query("SELECT COUNT(*) FROM visits WHERE ts >= DATE_SUB(NOW(), INTERVAL 10 SECOND)")->fetchColumn();
  $rs = $pdo->query("SELECT ip, COUNT(*) AS c10
                     FROM visits
                     WHERE ts >= DATE_SUB(NOW(), INTERVAL 10 SECOND)
                     GROUP BY ip
                     ORDER BY c10 DESC
                     LIMIT 10");
  $ips = [];
  while ($row = $rs->fetch(PDO::FETCH_ASSOC)) {
    $ips[] = [ 'ip' => $row['ip'], 'count10s' => (int)$row['c10'] ];
  }
  echo json_encode(['data' => [ 'total10s' => $total, 'top' => $ips ]]);
  exit;
}

if ($type === 'suspicious') {
  $rs = $pdo->query("SELECT s.ip, s.event, s.severity, DATE(s.created_at) as date, TIME(s.created_at) as time
                      FROM suspicious_activity s
                      LEFT JOIN blocked_ips b ON b.ip = s.ip
                      WHERE b.ip IS NULL
                      ORDER BY s.created_at DESC
                      LIMIT 200");
  $rows = [];
  while ($row = $rs->fetch(PDO::FETCH_ASSOC)) { $rows[] = $row; }
  echo json_encode(['data' => $rows]);
  exit;
}

if ($type === 'blocked') {
  $rs = $pdo->query("SELECT ip, reason, DATE(created_at) as date, TIME(created_at) as time FROM blocked_ips ORDER BY created_at DESC");
  $rows = [];
  while ($row = $rs->fetch(PDO::FETCH_ASSOC)) { $rows[] = $row; }
  echo json_encode(['data' => $rows]);
  exit;
}

if ($type === 'blocked_active') {
  $rs = $pdo->query("SELECT b.ip,
                             b.connections_at_block AS connections_5s,
                             (b.vpn_active_at_block+0) AS vpn_active,
                             b.packets_at_block AS packets_5s,
                             b.connections_total_at_block AS connections_total,
                             b.packet_type_at_block AS packet_type,
                             b.status_at_block AS status,
                             b.created_at AS blocked_at
                      FROM blocked_ips b
                      ORDER BY b.created_at DESC");
  $rows = [];
  while ($row = $rs->fetch(PDO::FETCH_ASSOC)) { $rows[] = $row; }
  echo json_encode(['data' => $rows]);
  exit;
}

http_response_code(400);
echo json_encode(['error' => 'bad_request']);
exit;
