<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}

function json_input(){
  $raw = file_get_contents('php://input');
  $j = json_decode($raw, true);
  return is_array($j) ? $j : [];
}

function visitor_ip(){
  if(!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
  if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
    $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
    return trim($parts[0]);
  }
  $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
  return $ip === '::1' ? '127.0.0.1' : $ip;
}

$ip = visitor_ip();
$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
$body = json_input();

$device = isset($body['device_id']) ? substr(preg_replace('/[^a-zA-Z0-9_-]/','',$body['device_id']),0,64) : null;
$country = $body['country'] ?? null;
$region = $body['region'] ?? null;
$city = $body['city'] ?? null;
$lat = isset($body['lat']) ? floatval($body['lat']) : null;
$lon = isset($body['lon']) ? floatval($body['lon']) : null;
$org = $body['org'] ?? null;
$vpn = isset($body['vpn']) ? (int)!!$body['vpn'] : null;
$proxy = isset($body['proxy']) ? (int)!!$body['proxy'] : null;
$tor = isset($body['tor']) ? (int)!!$body['tor'] : null;
$heartbeat = isset($body['heartbeat']) ? (bool)$body['heartbeat'] : false;

try{
  $pdo = getPDO();
  // Recent window: 5 minutes
  $stmt = $pdo->prepare('SELECT id FROM visits WHERE ip = ? AND (device_id = ? OR ? IS NULL) AND ts >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) ORDER BY id DESC LIMIT 1');
  $stmt->execute([$ip, $device, $device]);
  $row = $stmt->fetch();
  if($row){
    $id = $row['id'];
    $q = 'UPDATE visits SET user_agent = COALESCE(user_agent, ?), country = COALESCE(?, country), region = COALESCE(?, region), city = COALESCE(?, city), lat = COALESCE(?, lat), lon = COALESCE(?, lon), org = COALESCE(?, org), vpn = COALESCE(?, vpn), proxy = COALESCE(?, proxy), tor = COALESCE(?, tor), last_seen = ? WHERE id = ?';
    $pdo->prepare($q)->execute([$ua, $country, $region, $city, $lat, $lon, $org, $vpn, $proxy, $tor, now_lisbon(), $id]);
  }else{
    $q = 'INSERT INTO visits (ip,user_agent,ts,blocked,notes,device_id,country,region,city,lat,lon,org,vpn,proxy,tor,last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    $pdo->prepare($q)->execute([$ip,$ua,now_lisbon(),0,'tracked',$device,$country,$region,$city,$lat,$lon,$org,$vpn,$proxy,$tor, now_lisbon()]);
    $id = $pdo->lastInsertId();
  }

  if($heartbeat && !empty($id)){
    $pdo->prepare('UPDATE visits SET last_seen = ? WHERE id = ?')->execute([now_lisbon(), $id]);
  }

  $blocked = is_ip_blocked($ip) || is_device_blocked($device);
  echo json_encode(['ok'=>true,'blocked'=>$blocked,'visit_id'=>$id]);
}catch(Throwable $e){
  http_response_code(200);
  echo json_encode(['ok'=>false,'error'=>'db','message'=>$e->getMessage()]);
}
