<?php
// Ensures the Python agent (FastAPI) is running on 127.0.0.1:8000. If not, attempts to start it on Windows.
// Returns JSON with status info.

header('Content-Type: application/json');

// If a remote AGENT_BASE_URL is configured, skip any local start attempts
$configPath = realpath(__DIR__ . '/../config.php');
if ($configPath && file_exists($configPath)) {
    @include_once $configPath;
}

// If agent base is configured and not local, report remote so callers don't try to start
$agentBaseUrl = defined('AGENT_BASE_URL') ? AGENT_BASE_URL : (getenv('AGENT_BASE_URL') ?: null);
if ($agentBaseUrl && stripos($agentBaseUrl, '127.0.0.1') === false && stripos($agentBaseUrl, 'localhost') === false) {
    echo json_encode(['status' => 'remote', 'message' => 'remote agent configured', 'agent_base' => $agentBaseUrl]);
    exit;
}

function agent_up(): bool {
    $ch = curl_init('http://127.0.0.1:8000/debug/routes');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 2);
    $resp = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE) ?: 0;
    curl_close($ch);
    return $status === 200 && $resp !== false;
}

try {
    if (agent_up()) {
        echo json_encode(['status' => 'up']);
        exit;
    }

    $base = realpath(__DIR__ . '/../IA REBORN');
    if (!$base) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'error' => 'base_not_found']);
        exit;
    }

    // Prefer using PowerShell script that prepares venv, installs deps, and starts uvicorn
    $batScript = $base . DIRECTORY_SEPARATOR . 'scripts' . DIRECTORY_SEPARATOR . 'auto_start_agent.bat';
    $psScript = $base . DIRECTORY_SEPARATOR . 'scripts' . DIRECTORY_SEPARATOR . 'auto_start_agent.ps1';
    $tried = [];
    $started = false;
    if (file_exists($batScript)) {
        // Prefer BAT to avoid PowerShell policy issues
        $cmd = 'cmd /c start "" ' . '"' . $batScript . '"';
        $tried[] = $cmd;
        @pclose(@popen($cmd . ' >NUL 2>&1', 'r'));
    } elseif (file_exists($psScript)) {
        // Resolve PowerShell path (prefer pwsh if present), else fallback to powershell
        $pwsh = getenv('ProgramFiles') . '\\PowerShell\\7\\pwsh.exe';
        if ($pwsh && file_exists($pwsh)) {
            $ps = '"' . $pwsh . '"';
        } else {
            $ps = 'powershell';
        }
        // Run PowerShell without window, bypass policy, background
        $cmd = $ps . ' -ExecutionPolicy Bypass -NoProfile -File ' . '"' . $psScript . '"';
        $tried[] = $cmd;
        @pclose(@popen('cmd /c start "" ' . $cmd . ' >NUL 2>&1', 'r'));
    } else {
        // Fallback to direct python spawn if script missing
        $venvPy = $base . DIRECTORY_SEPARATOR . '.venv_agent' . DIRECTORY_SEPARATOR . 'Scripts' . DIRECTORY_SEPARATOR . 'python.exe';
        $candidates = [];
        if (file_exists($venvPy)) { $candidates[] = '"' . $venvPy . '"'; }
        $candidates[] = 'py -3';
        $candidates[] = 'python';
        foreach ($candidates as $py) {
            $cmd = 'cmd /c start "" /D ' . '"' . $base . '"' . ' /B ' . $py . ' -m uvicorn agent:app --host 127.0.0.1 --port 8000';
            $tried[] = $cmd;
            @pclose(@popen($cmd . ' >NUL 2>&1', 'r'));
            usleep(200000);
            if (agent_up()) { $started = true; break; }
        }
    }

    // Retry checks with small backoff up to ~15s total (first run may install deps)
    $retries = 60; // 60 * 250ms ~ 15s
    for ($i=0; $i<$retries && !$started; $i++) {
        usleep(250000);
        if (agent_up()) { $started = true; break; }
    }

    if ($started) {
    echo json_encode(['status' => 'starting', 'message' => 'agent launching', 'tried' => $tried]);
        exit;
    } else {
        // Include tail of log files to help diagnose
        $logs = [];
        $logDir = $base . DIRECTORY_SEPARATOR . 'logs';
        $lf = $logDir . DIRECTORY_SEPARATOR . 'autostart_latest.log';
        $outf = $logDir . DIRECTORY_SEPARATOR . 'uvicorn_out.log';
        $errf = $logDir . DIRECTORY_SEPARATOR . 'uvicorn_err.log';
        foreach ([$lf, $outf, $errf] as $f) {
            if (file_exists($f)) {
                $content = @file($f);
                if ($content !== false) {
                    $logs[basename($f)] = implode("", array_slice($content, -80));
                }
            }
        }
        http_response_code(500);
        echo json_encode(['status' => 'failed', 'error' => 'agent_not_started', 'tried' => $tried, 'logs' => $logs]);
        exit;
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'error' => $e->getMessage()]);
    exit;
}
