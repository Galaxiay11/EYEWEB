<?php
// Serve the admin chat JS via PHP to bypass host 403 rules on static .js files
header('Content-Type: application/javascript; charset=utf-8');
// Avoid aggressive caching while we iterate
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$jsPath = realpath(__DIR__ . '/../js/agent_chat.js');
if (!$jsPath || !is_file($jsPath)) {
    http_response_code(404);
    echo "// agent chat script not found";
    exit;
}

// Optionally, could minify or transform here if needed
readfile($jsPath);
