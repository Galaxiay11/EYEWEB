<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['user'])) { http_response_code(401); echo json_encode(['error' => 'unauthorized']); exit; }

$ip = $_POST['ip'] ?? '';
if (!filter_var($ip, FILTER_VALIDATE_IP)) { http_response_code(400); echo json_encode(['error' => 'invalid_ip']); exit; }

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();

$stmt = $pdo->prepare('DELETE FROM blocked_ips WHERE ip = ?');
$ok = $stmt->execute([$ip]);

// Limpa dados antigos para não reexibir histórico ao desbloquear
try { $pdo->prepare('DELETE FROM active_connections WHERE ip = ?')->execute([$ip]); } catch (Throwable $e) {}
try { $pdo->prepare('DELETE FROM suspicious_activity WHERE ip = ?')->execute([$ip]); } catch (Throwable $e) {}

$pdo = null;

echo json_encode(['ok' => (bool)$ok]);
exit;
