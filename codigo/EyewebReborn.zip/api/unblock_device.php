<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['user'])) { http_response_code(401); echo json_encode(['error'=>'unauthorized']); exit; }
require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();
$input = $_POST;
$did = $input['device_id'] ?? '';
if (!$did) { http_response_code(400); echo json_encode(['error'=>'missing_device_id']); exit; }
$pdo->prepare('DELETE FROM blocked_devices WHERE device_id=?')->execute([$did]);
$pdo->prepare('UPDATE visits SET blocked=0 WHERE device_id=?')->execute([$did]);
echo json_encode(['ok'=>true]);
