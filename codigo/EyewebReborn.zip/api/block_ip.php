<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['user'])) { http_response_code(401); echo json_encode(['error' => 'unauthorized']); exit; }

$ip = $_POST['ip'] ?? '';
$reason = $_POST['reason'] ?? 'Bloqueio manual';
if (!filter_var($ip, FILTER_VALIDATE_IP)) { http_response_code(400); echo json_encode(['error' => 'invalid_ip']); exit; }

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();

$snap = $pdo->prepare('SELECT connections_5s, packets_5s, connections_total, status, packet_type, vpn_active FROM active_connections WHERE ip = ?');
$snap->execute([$ip]);
$snapRes = $snap->fetch(PDO::FETCH_ASSOC);
$c = 0; $p = 0; $ctot = 0; $s = 'Bloqueado'; $pt = 'TCP'; $va = 0;
if ($snapRes) {
	$c = (int)$snapRes['connections_5s'];
	$p = (int)$snapRes['packets_5s'];
	$ctot = (int)$snapRes['connections_total'];
	$s = $snapRes['status'] ?? 'Bloqueado';
	$pt = $snapRes['packet_type'] ?? 'TCP';
	$va = (int)$snapRes['vpn_active'];
}

$stmt = $pdo->prepare('REPLACE INTO blocked_ips (ip, reason, connections_at_block, packets_at_block, connections_total_at_block, status_at_block, packet_type_at_block, vpn_active_at_block) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
$ok = $stmt->execute([$ip, $reason, $c, $p, $ctot, $s, $pt, $va]);

// Inserir em suppressed_ips para manter o IP escondido futuramente
@($pdo->prepare('REPLACE INTO suppressed_ips (ip, reason) VALUES (?, ?)')->execute([$ip, 'blocked-once']));
@($pdo->prepare('DELETE FROM active_connections WHERE ip = ?')->execute([$ip]));

echo json_encode(['ok' => (bool)$ok]);
exit;
