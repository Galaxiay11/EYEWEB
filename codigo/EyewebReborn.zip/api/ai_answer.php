<?php
// EyeWeb AI answer endpoint (safe name to avoid host WAF rules blocking "chat.php")
// Accepts GET ?q=... (primary). Fallbacks: ?m=..., ?admin_prompt=...
// Responds with JSON: { answer: string, attachments?: [ { filename, content_type, content_base64 } ] }
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}

function jserr($msg, $code=400){ http_response_code($code); echo json_encode(['error'=>$msg]); exit; }

// Read prompt from benign param names first to dodge naive WAF keyword rules
$prompt = '';
if (isset($_GET['q'])) $prompt = trim((string)$_GET['q']);
elseif (isset($_GET['m'])) $prompt = trim((string)$_GET['m']);
elseif (isset($_GET['admin_prompt'])) $prompt = trim((string)$_GET['admin_prompt']);
elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // also allow simple form posts
  if (isset($_POST['q'])) $prompt = trim((string)$_POST['q']);
  elseif (isset($_POST['m'])) $prompt = trim((string)$_POST['m']);
  elseif (isset($_POST['admin_prompt'])) $prompt = trim((string)$_POST['admin_prompt']);
}
if ($prompt === '') { jserr('prompt vazio'); }

// Helpers
function s_norm($s){
  $t = @iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$s);
  if ($t===false || $t===null) $t = (string)$s;
  return strtolower($t);
}
function safe_row($row){ if(!is_array($row)) return $row; foreach($row as $k=>$v){ if ($v===null) $row[$k]=''; } return $row; }

// DB
$pdo = null; $db_error = null;
try { $pdo = getPDO(); } catch (Throwable $e) { $db_error = $e->getMessage(); }
if (!$pdo) { jserr('BD indisponível', 503); }

$pl = s_norm($prompt);

// --- Intent helpers: tolerant keyword/stem matching (handles typos and accents removed) ---
function tokens_of($s){
  $t = preg_split('/[^a-z0-9]+/i', $s); return array_values(array_filter($t, fn($x)=>$x!==''));
}
function has_stem($s, $stems){
  foreach ($stems as $st){ if ($st!=='' && strpos($s, $st)!==false) return true; }
  return false;
}
function approx_has($s, $words, $maxDist=1){
  $tk = tokens_of($s); if (empty($tk)) return false;
  foreach ($tk as $t){
    foreach ($words as $w){
      if ($t===$w) return true;
      if (function_exists('levenshtein')){
        if (levenshtein($t, $w) <= $maxDist) return true;
      }
    }
  }
  return false;
}
function want_list_blocked_ips($pl){
  // Match any of: (ip|ips) + (list/show/see) OR mention of blocked/ban
  $hasIp   = has_stem($pl, [' ip','ip ']) || preg_match('/\bip(s)?\b/i', $pl);
  $hasShow = has_stem($pl, ['list','mostr','ver']) || approx_has($pl, ['listar','lista','mostrar','ver']);
  $hasBlk  = has_stem($pl, ['bloque','block','banid','ban']) || approx_has($pl, ['bloqueados','bloqueado','banidos','banido','blocked']);
  return $hasIp && ($hasShow || $hasBlk);
}
function want_report($pl){
  return has_stem($pl, ['relator','report']) || approx_has($pl, ['relatorio','relatório','report']);
}

// Friendly small-talk and scope helpers
function topics_text(){
  $topics = [
    'Listar IPs/Dispositivos bloqueados',
    'Gerar relatório (.txt) do sistema',
    'Verificar senha na tabela password_data',
    'Verificar email na tabela personal_data',
    'Analisar URL na tabela malicious_links',
    'Consultar ataques recentes (defense)'
  ];
  return '- '.implode("\n- ", $topics);
}
function is_greeting($pl){
  $keys = ['oi','ola','olá','bom dia','boa tarde','boa noite','como estas','como esta','tudo bem','hey','hello','hi'];
  foreach ($keys as $k){ if (strpos($pl,$k)!==false) return true; }
  return false;
}
function is_purpose($pl){
  $stems = ['para que serv','o que faz','que podes faz','como podes ajud','ajuda','help','qual a tua func','qual e a tua func'];
  foreach ($stems as $s){ if (strpos($pl,$s)!==false) return true; }
  return false;
}

// 0) Greetings / purpose
if (is_greeting($pl)){
  $ans = "Olá! Sou o EyeWeb Agent. Posso ajudar em tópicos de segurança do site. Tópicos que cubro:\n".topics_text()."\n\nExemplos: 'listar ips bloqueados', 'gerar relatório', 'analisar url http://…'";
  echo json_encode(['answer'=>$ans]); exit;
}
if (is_purpose($pl)){
  $ans = "Sou um assistente para operações de segurança do EyeWeb. O que posso fazer:\n".topics_text()."\n\nPergunta-me, por exemplo: 'listar ips bloqueados' ou 'verificar senha 123456'.";
  echo json_encode(['answer'=>$ans]); exit;
}

// 1) List blocked IPs (tolerant to typos and variants)
if (want_list_blocked_ips($pl)) {
  try{
    $rows = [];
    $stmt = $pdo->query("SELECT ip, COALESCE(last_seen, ts) AS ts FROM visits WHERE blocked=1 ORDER BY COALESCE(last_seen, ts) DESC LIMIT 50");
    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) { $rows[] = ['ip'=>$r['ip'],'ts'=>$r['ts']]; }
    try{
      $stmt2 = $pdo->query("SELECT ip, blocked_at AS ts FROM blocked_ips ORDER BY blocked_at DESC LIMIT 50");
      while ($r = $stmt2->fetch(PDO::FETCH_ASSOC)) { $rows[] = ['ip'=>$r['ip'],'ts'=>$r['ts']]; }
    }catch(Throwable $e2){}
    $byip = [];
    foreach ($rows as $r){ $ip=$r['ip']; if(!isset($byip[$ip]) || strcmp((string)$r['ts'], (string)$byip[$ip]['ts'])>0){ $byip[$ip]=$r; } }
    usort($byip, function($a,$b){ return strcmp((string)$b['ts'], (string)$a['ts']); });
    $out = []; $i=0; foreach ($byip as $r){ $out[] = ($r['ts']?:'?').' | '.$r['ip']; if(++$i>=50) break; }
    $ans = empty($out)?'Ainda não há IPs bloqueados.':("IPs bloqueados (site):\n".implode("\n",$out));
    echo json_encode(['answer'=>$ans]); exit;
  }catch(Throwable $e){ jserr('erro ao listar ips: '.$e->getMessage(), 500); }
}

// 2) Generate report (fuzzy)
if (want_report($pl)) {
  try{
    $counts = [];
    foreach (['personal_data','malicious_links','password_data','visits','blocked_ips','attacks'] as $tbl){
      try{ $counts[$tbl] = (int)$pdo->query("SELECT COUNT(*) FROM $tbl")->fetchColumn(); }catch(Throwable $e){ $counts[$tbl]=0; }
    }
    $lines = [];
    $lines[] = 'EyeWeb Report';
    $lines[] = 'Generated at: '.date('Y-m-d H:i:s');
    $lines[] = '';
    foreach($counts as $k=>$v){ $lines[] = sprintf('%-16s: %d', $k, $v); }
    $lines[]='';
    try{
      $stmt=$pdo->query("SELECT ip, rule, detected_at FROM attacks ORDER BY detected_at DESC LIMIT 5");
      $lines[]='Last attacks:';
      while ($r=$stmt->fetch(PDO::FETCH_ASSOC)){
        $lines[] = sprintf('  %s | %s | %s', $r['detected_at']?:'?', $r['ip']?:'-', $r['rule']?:'-');
      }
    }catch(Throwable $e){}
    $content = implode("\n", $lines)."\n";
    $b64 = base64_encode($content);
    $att = [ 'filename'=>'eyeweb_report_'.date('Ymd_His').'.txt', 'content_type'=>'text/plain; charset=utf-8', 'content_base64'=>$b64 ];
    echo json_encode(['answer'=>'Relatório gerado e anexado (download automático).','attachments'=>[$att]]); exit;
  }catch(Throwable $e){ jserr('erro ao gerar relatório: '.$e->getMessage(), 500); }
}

// 3) Check password — accept: "senha 123", "password: 123", "pwd 123"
if (preg_match('/\b(senha|password|pass|pwd)\b[^\S\r\n]*[:\-]?\s*(\S{3,})/i', $prompt, $m)){
  $pw = $m[2];
  try{
    $stmt = $pdo->prepare('SELECT category FROM password_data WHERE password = ? LIMIT 1');
    $stmt->execute([$pw]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row){ $cat=$row['category']??''; $ans='Senha encontrada na tabela password_data'.($cat?" (categoria: $cat)":''); }
    else { $ans='Senha não encontrada nas bases locais.'; }
    echo json_encode(['answer'=>$ans]); exit;
  }catch(Throwable $e){ jserr('erro ao verificar senha: '.$e->getMessage(), 500); }
}

// 4) Check email
if (preg_match('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', $prompt, $m)){
  $email = $m[0];
  try{
    $stmt = $pdo->prepare('SELECT name, phone, email FROM personal_data WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row){
      $row=safe_row($row); $extra=[]; if($row['name']!=='') $extra[]='nome: '.$row['name']; if($row['phone']!=='') $extra[]='telefone: '.$row['phone'];
      $ans='Email encontrado em personal_data'.(!empty($extra)?' ('.implode(', ',$extra).')':'');
    } else { $ans='Email não encontrado nas bases locais.'; }
    echo json_encode(['answer'=>$ans]); exit;
  }catch(Throwable $e){ jserr('erro ao verificar email: '.$e->getMessage(), 500); }
}

// 5) Analyze URL
if (preg_match('/https?:\/\/[^\s,;\'\"]+/i', $prompt, $m)){
  $url = $m[0];
  try{
    $stmt=$pdo->prepare('SELECT url, phishing, insecure, coleta, attack_type, attack_date FROM malicious_links WHERE url = ? LIMIT 1');
    $stmt->execute([$url]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row){ $stmt=$pdo->prepare('SELECT url, phishing, insecure, coleta, attack_type, attack_date FROM malicious_links WHERE url LIKE ? LIMIT 1'); $stmt->execute(['%'.$url.'%']); $row=$stmt->fetch(PDO::FETCH_ASSOC); }
    if ($row){
      $flags=[]; if(!empty($row['phishing'])) $flags[]='phishing'; if(!empty($row['insecure'])) $flags[]='insecure'; if(!empty($row['coleta'])) $flags[]='coleta';
      $extra=[]; if(!empty($row['attack_type'])) $extra[]='tipo: '.$row['attack_type']; if(!empty($row['attack_date']) && $row['attack_date']!=='0000-00-00') $extra[]='data: '.$row['attack_date'];
      $ans='URL encontrada na tabela malicious_links'.(!empty($flags)?'; '.implode(', ',$flags):'').(!empty($extra)?'; '.implode(', ',$extra):'');
    } else { $ans='URL não encontrada nas bases locais.'; }
    echo json_encode(['answer'=>$ans]); exit;
  }catch(Throwable $e){ jserr('erro ao analisar url: '.$e->getMessage(), 500); }
}

// 6) Fallback
// If chegou aqui, o assunto provavelmente está fora do escopo de segurança.
$ans = "Falo apenas sobre estes tópicos de segurança:\n".topics_text()."\n\nSe precisar de algo fora deste âmbito (ex.: comida, futebol, etc.), não consigo ajudar. Tente uma destas opções do meu escopo.";
echo json_encode(['answer'=>$ans]);
exit;
