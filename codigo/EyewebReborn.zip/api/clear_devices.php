<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user'])) {
  http_response_code(401);
  echo json_encode(['error' => 'unauthorized']);
  exit;
}

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();

try {
  // Clear tracked visits; keep schema and blocked lists intact
  $pdo->exec("DELETE FROM visits");
  echo json_encode(['ok' => true]);
} catch (Throwable $e) {
  http_response_code(200);
  echo json_encode(['ok' => false, 'error' => 'db', 'message' => $e->getMessage()]);
}
exit;
