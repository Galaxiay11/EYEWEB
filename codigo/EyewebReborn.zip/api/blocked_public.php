<?php
// Public (token-protected) endpoint to list blocked IPs for the agent/relay to consume.
// Does NOT require a login session. Validate using a shared token from security/config.php ('agent_token')
// or fallback to AGENT_SHARED_SECRET if configured.
header('Content-Type: application/json; charset=utf-8');

// Load config array
$cfg = require __DIR__ . '/../security/config.php';
$expected = (string)($cfg['agent_token'] ?? '');
if (!$expected) {
    // Backward-compat: allow AGENT_SHARED_SECRET constant/env
    $expected = defined('AGENT_SHARED_SECRET') ? (string)AGENT_SHARED_SECRET : (getenv('AGENT_SHARED_SECRET') ?: '');
}

// Check token from header or query
$ok = false;
$hdrs = function_exists('getallheaders') ? getallheaders() : [];
if (!empty($hdrs['Authorization']) && stripos($hdrs['Authorization'], 'Bearer ') === 0) {
    $tok = trim(substr($hdrs['Authorization'], 7));
    if ($expected && hash_equals($expected, $tok)) $ok = true;
}
if (!$ok && isset($_GET['token'])) {
    if ($expected && hash_equals($expected, (string)$_GET['token'])) $ok = true;
}
if (!$ok) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();

// Build a merged list: first from visits where blocked=1, then overlay with blocked_ips (if present)
$byIp = [];

// 1) From visits table (user requested): blocked flag = 1
$sqlVisits = "SELECT ip, COALESCE(MAX(last_seen), MAX(ts)) AS last_ts
              FROM visits
              WHERE blocked = 1 AND ip IS NOT NULL AND ip <> ''
              GROUP BY ip
              ORDER BY last_ts DESC
              LIMIT 200";
try {
    $rs1 = $pdo->query($sqlVisits);
    while ($row = $rs1->fetch(PDO::FETCH_ASSOC)) {
        $ip = $row['ip']; if (!$ip) continue;
        $byIp[$ip] = [
            'ip' => $ip,
            'source' => 'visits.blocked',
            'ts' => $row['last_ts']
        ];
    }
} catch (Throwable $e) { /* ignore */ }

// 2) From blocked_ips (if available), prefer explicit blocked_ips timestamps/reasons
$sqlBlk = "SELECT ip, reason, blocked_at FROM blocked_ips ORDER BY blocked_at DESC LIMIT 200";
try {
    $rs2 = $pdo->query($sqlBlk);
    while ($row = $rs2->fetch(PDO::FETCH_ASSOC)) {
        $ip = $row['ip']; if (!$ip) continue;
        if (!isset($byIp[$ip])) {
            $byIp[$ip] = [ 'ip' => $ip, 'source' => 'blocked_ips', 'reason' => ($row['reason'] ?? null), 'ts' => $row['blocked_at'] ];
        } else {
            // choose newer timestamp
            $cur = strtotime((string)($byIp[$ip]['ts'] ?? '1970-01-01 00:00:00'));
            $new = strtotime((string)($row['blocked_at'] ?? '1970-01-01 00:00:00'));
            if ($new && $new > $cur) {
                $byIp[$ip]['ts'] = $row['blocked_at'];
            }
            if (!empty($row['reason'])) $byIp[$ip]['reason'] = $row['reason'];
        }
    }
} catch (Throwable $e) { /* ignore */ }

// Convert map to list and sort by ts DESC
$rows = array_values($byIp);
usort($rows, function($a,$b){
    $ta = strtotime((string)($a['ts'] ?? '1970-01-01 00:00:00'));
    $tb = strtotime((string)($b['ts'] ?? '1970-01-01 00:00:00'));
    return $tb <=> $ta;
});

echo json_encode(['ips' => array_slice($rows, 0, 100)], JSON_UNESCAPED_UNICODE);
exit;
?>
