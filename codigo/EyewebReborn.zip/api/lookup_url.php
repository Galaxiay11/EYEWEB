<?php
header('Content-Type: application/json; charset=utf-8');
@date_default_timezone_set('Europe/Lisbon');

function get_token(){
  $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['Authorization'] ?? '';
  if ($auth && stripos($auth, 'bearer ') === 0) return trim(substr($auth, 7));
  return $_GET['token'] ?? $_POST['token'] ?? '';
}

try{
  $cfg = require __DIR__ . '/../security/config.php';
  $token = get_token();
  $expected = $cfg['agent_token'] ?? '';
  if(!$expected){ http_response_code(401); echo json_encode(['error'=>'token_not_configured']); exit; }
  if(!$token || !hash_equals($expected, (string)$token)){
    http_response_code(403); echo json_encode(['error'=>'invalid_token']); exit;
  }
  if(!isset($_GET['url']) && !isset($_POST['url'])){
    http_response_code(400); echo json_encode(['error'=>'missing_url']); exit;
  }
  $url = (string)($_GET['url'] ?? $_POST['url']);
  require_once __DIR__ . '/../security/db.php';
  $pdo = getPDO();
  $s = $pdo->prepare('SELECT phishing, insecure, coleta, attack_type, attack_date FROM malicious_links WHERE url = ? LIMIT 1');
  $s->execute([$url]);
  $row = $s->fetch(PDO::FETCH_ASSOC);
  if($row){
    // normalize integers
    foreach(['phishing','insecure','coleta'] as $k){ if(isset($row[$k])) $row[$k] = (int)$row[$k]; }
    echo json_encode(['found'=>true] + $row);
  }else{
    echo json_encode(['found'=>false]);
  }
}catch(Throwable $e){
  http_response_code(500); echo json_encode(['error'=>'server_error','detail'=>$e->getMessage()]);
}
