<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user'])) {
  http_response_code(401);
  echo json_encode(['error' => 'unauthorized']);
  exit;
}

require_once __DIR__ . '/../security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();
$ok = $pdo->exec("DELETE FROM suspicious_activity");

echo json_encode(['ok' => (bool)$ok]);
exit;
