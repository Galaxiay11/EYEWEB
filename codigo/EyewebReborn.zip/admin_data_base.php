<?php
require_once __DIR__ . '/inc/defense_bootstrap.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION['user'])) {
  header('Location: login.php');
  exit();
}

require_once __DIR__ . '/security/db.php';
try { ensure_schema(); } catch (Throwable $e) {}
$pdo = getPDO();


// SRP: helpers to build parts of the table so each function has one responsibility
function renderHeaderHtml(string $title, array $columnNames): string {
  $out = "<h2>" . htmlspecialchars($title) . "</h2>";
  $out .= "<div class='data-table-wrapper'><table class='data-table'><thead><tr>";
  foreach ($columnNames as $col) {
    $out .= "<th>" . htmlspecialchars($col) . "</th>";
  }
  $out .= "<th>Ações</th></tr></thead><tbody>";
  return $out;
}

function renderActionsHtml($id, $tableTitle): string {
  $idEsc = urlencode((string)$id);
  $tableEsc = urlencode((string)$tableTitle);
  return "<a href='editar.php?id={$idEsc}&table={$tableEsc}' class='btn-edit' title='Editar'><i class='fa-solid fa-pen'></i></a>"
       . " <a href='eliminar.php?id={$idEsc}&table={$tableEsc}' class='btn-delete' title='Eliminar' onclick=\"return confirm('Tem certeza?')\"><i class='fa-solid fa-trash'></i></a>";
}

function renderRowHtml(array $row, array $columnNames, string $tableTitle): string {
  $out = "<tr>";
  foreach ($columnNames as $col) {
    $value = isset($row[$col]) ? htmlspecialchars((string)$row[$col]) : '';
    $out .= "<td data-label='" . htmlspecialchars($col) . "'>$value</td>";
  }
  $id = $row['id'] ?? '';
  $out .= "<td class='action-icons'>" . renderActionsHtml($id, $tableTitle) . "</td>";
  $out .= "</tr>";
  return $out;
}

function renderTable(array $rows, string $title) {
  if ($rows && count($rows) > 0) {
    $columnNames = array_keys($rows[0]);

    // header
    echo renderHeaderHtml($title, $columnNames);

    // rows
    foreach ($rows as $row) {
      echo renderRowHtml($row, $columnNames, $title);
    }

    // footer / close tags
    echo "</tbody></table></div><hr>";
  } else {
    echo "<h2>" . htmlspecialchars($title) . "</h2><p>Sem dados encontrados.</p><hr>";
  }
}

try { $personal = $pdo->query("SELECT * FROM personal_data")->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) { die("Erro na query personal_data: ".$e->getMessage()); }

try { $links = $pdo->query("SELECT * FROM malicious_links")->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) { die("Erro na query malicious_links: ".$e->getMessage()); }

try { $passwords = $pdo->query("SELECT * FROM password_data")->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $e) { die("Erro na query password_data: ".$e->getMessage()); }

?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>EyeWeb Admin</title>
  <link rel="stylesheet" href="css/admin_data_base.css">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">

 <nav class="navbar">
   <a href="admin.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
    <a href="admin.php" class="nav-link">Add Data</a>
    <a href="admin_data_base.php" class="nav-link active">View Data</a>
    <a href="defense.php" class="nav-link">Defesas</a>

    <a class="nav-icon" id="user-icon" title="Login">
      <i class="fa-solid fa-user"></i>
    </a>

    <div id="user-popup" class="user-popup hide">
      <p>User: Admin</p>
      <a href="logout.php" title="Sair">
        <i class="fa-solid fa-right-from-bracket logout-icon"></i>
      </a>
    </div>
   </div>
 </nav>

  <header class="header container">
     <h1>Base de Dados</h1>
    <h2>Verificar e alterar informações</h2>
  </header>

<main class="container">
  <div class="submenu">
    <button class="submenu-btn active" data-target="section-personal">Dados Pessoais</button>
    <button class="submenu-btn" data-target="section-links">Links Maliciosos</button>
    <button class="submenu-btn" data-target="section-passwords">Passwords Vazadas</button>
  </div>

  <div id="section-personal" class="data-section">
    <?php renderTable($personal, 'personal_data'); ?>
  </div>
  <div id="section-links" class="data-section hide">
    <?php renderTable($links, 'malicious_links'); ?>
  </div>
  <div id="section-passwords" class="data-section hide">
    <?php renderTable($passwords, 'password_data'); ?>
  </div>
</main>

<script>
  // In admin area, force the chat bubble to be shown immediately
  try { sessionStorage.setItem('eyeSeen','true'); } catch(e) {}
</script>
<script>
  // Fallback loader: if chat script didn’t initialize, reload it via PHP (bypasses 403 on static .js)
  setTimeout(function(){
    try{
      if (!window.__EW_AGENT_CHAT_READY){
        var s=document.createElement('script');
        s.src = '/api/widget_js.php?v=' + Date.now();
        document.body.appendChild(s);
      }
    }catch(e){}
  }, 600);
</script>
<script src="js/admin_data_base.js"></script>
<script>
  // Use remote relay to avoid host blocking
  window.AGENT_RELAY_URL = 'https://relay-g4bv.onrender.com/chat';
</script>
<script src="/api/widget_js.php"></script>
</body>
</html>