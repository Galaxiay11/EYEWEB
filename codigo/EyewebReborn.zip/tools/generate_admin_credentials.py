import argparse
import base64
import hashlib
import hmac
import os
import subprocess
import tempfile
import time

# This script reproduces the same algorithm as login.php to derive time-based credentials
# Make sure ADMIN_SECRET, ADMIN_STEP_SECONDS, ADMIN_SKEW_STEPS, ADMIN_USERNAME_PREFIX,
# ADMIN_USER_SUFFIX_LENGTH, ADMIN_PASSWORD_LENGTH match config.php.

ADMIN_SECRET = os.environ.get("EYEWEB_ADMIN_SECRET", "CHANGE_ME___Va1dS3cr3t_L0ng_Random_Base")
ADMIN_USERNAME_PREFIX = os.environ.get("EYEWEB_ADMIN_PREFIX", "admin")
ADMIN_STEP_SECONDS = int(os.environ.get("EYEWEB_ADMIN_STEP", "60"))
ADMIN_SKEW_STEPS = int(os.environ.get("EYEWEB_ADMIN_SKEW", "0"))
ADMIN_USER_SUFFIX_LENGTH = int(os.environ.get("EYEWEB_ADMIN_USER_SUFFIX", "6"))
ADMIN_PASSWORD_LENGTH = int(os.environ.get("EYEWEB_ADMIN_PASSWORD_LEN", "20"))

ALPHABET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+[]{}<>?/.,~'


def hmac_sha256(key: bytes, msg: bytes) -> bytes:
    return hmac.new(key, msg, hashlib.sha256).digest()


def derive_for_step(step: int):
    msg = f"admin-login|{step}".encode()
    mac = hmac_sha256(ADMIN_SECRET.encode(), msg)

    num = int.from_bytes(mac[:4], 'big') & 0x7FFFFFFF
    suffix = str(num % (10 ** ADMIN_USER_SUFFIX_LENGTH)).zfill(ADMIN_USER_SUFFIX_LENGTH)
    username = f"{ADMIN_USERNAME_PREFIX}{suffix}"

    mac2 = mac + hmac_sha256(ADMIN_SECRET.encode(), f"admin-login-extend|{step}".encode())
    pwd = ''.join(ALPHABET[b % len(ALPHABET)] for b in mac2[:ADMIN_PASSWORD_LENGTH])
    return username, pwd


def main():
    parser = argparse.ArgumentParser(description="Generate time-based admin credentials for EyeWeb")
    parser.add_argument("--skew", type=int, default=0, help="Optional step offset for preview (-1,0,1)")
    parser.add_argument("--out", type=str, default="", help="Optional output file path (if omitted, use a temporary file)")
    args = parser.parse_args()

    now = int(time.time())
    step = now // ADMIN_STEP_SECONDS + args.skew
    username, password = derive_for_step(step)

    content = (
        f"username: {username}\n"
        f"password: {password}\n"
        f"valid_for_seconds: {ADMIN_STEP_SECONDS}\n"
        f"generated_at_epoch: {now}\n"
        f"note: Keep clocks in sync with the server.\n"
    )
    out_path = args.out
    if not out_path:
        # Create a temporary file that Notepad can open; we'll leave it for manual close
        tmp = tempfile.NamedTemporaryFile(prefix="eyeweb_admin_", suffix=".txt", delete=False)
        out_path = tmp.name
        tmp.write(content.encode('utf-8'))
        tmp.flush()
        tmp.close()
    else:
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(content)

    print("Credentials prepared at:", out_path)
    try:
        # Open Notepad on Windows
        subprocess.Popen(["notepad", out_path])
    except Exception as e:
        print("Failed to open Notepad:", e)
        print("Content:\n" + content)


if __name__ == "__main__":
    main()
