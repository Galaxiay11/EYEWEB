@echo off
setlocal enabledelayedexpansion

:: Batch wrapper to run the Python generator; Python will open Notepad itself
set SCRIPT_DIR=%~dp0

:: Allow overriding via environment variables if needed
:: set EYEWEB_ADMIN_SECRET=CHANGE_ME___Va1dS3cr3t_L0ng_Random_Base
:: set EYEWEB_ADMIN_STEP=60
:: set EYEWEB_ADMIN_SKEW=0
:: set EYEWEB_ADMIN_PREFIX=admin
:: set EYEWEB_ADMIN_USER_SUFFIX=6
:: set EYEWEB_ADMIN_PASSWORD_LEN=20

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo Python not found in PATH. Please install Python 3 and try again.
    exit /b 1
)

python "%SCRIPT_DIR%generate_admin_credentials.py"
if %errorlevel% neq 0 (
    echo Failed to generate credentials.
    exit /b 1
)

echo.
echo Credentials generated and opened in Notepad.
rem pausa até o utilizador pressionar qualquer tecla
pause
exit /b 0
