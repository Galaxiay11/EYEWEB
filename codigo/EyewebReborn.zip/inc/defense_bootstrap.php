<?php
// Bootstrap de defesa: cria tabelas (se necessário), bloqueia IPs e regista pedidos

// Evitar múltiplas inclusões
if (defined('EYEWEB_DEFENSE_BOOTSTRAPPED')) return;
define('EYEWEB_DEFENSE_BOOTSTRAPPED', true);

// Logger leve para erros/fatais (útil em hosts que escondem erros)
if (!defined('EYEWEB_ERROR_LOGGER')) {
  define('EYEWEB_ERROR_LOGGER', true);
  $EW_LOG_FILE = dirname(__DIR__) . '/security/error.log';
  $logFn = function($line) use ($EW_LOG_FILE) {
    $ts = date('Y-m-d H:i:s');
    @file_put_contents($EW_LOG_FILE, "[$ts] $line\n", FILE_APPEND);
  };
  set_error_handler(function($errno, $errstr, $errfile, $errline) use ($logFn){
    $logFn("PHP[$errno] $errstr in $errfile:$errline");
    return false; // deixar PHP continuar handling normal
  });
  set_exception_handler(function($ex) use ($logFn){
    $logFn('Uncaught '.get_class($ex).': '.$ex->getMessage().' @ '.$ex->getFile().':'.$ex->getLine());
  });
  register_shutdown_function(function() use ($logFn){
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
      $logFn('Fatal: '.$e['message'].' @ '.$e['file'].':'.$e['line']);
    }
  });
}

// Log de arranque do bootstrap (para depuração no alojamento)
if (function_exists('date')) {
  $EW_BOOT_LOG = function($msg) use ($logFn) {
    if (isset($logFn)) $logFn('[BOOT] '.$msg);
  };
  $EW_BOOT_LOG('start script='.basename($_SERVER['SCRIPT_NAME'] ?? 'unknown'));
}

// Iniciar sessão apenas se necessário (para saber se é admin e permitir bypass)
if (session_status() === PHP_SESSION_NONE) {
  @session_start();
}

// Integração com o guard/tracker (sempre relativo ao projeto atual)
try {
  $projectRoot = dirname(__DIR__); // .../EyeWeb
  $guardPath = $projectRoot . '/security/guard.php';
  if (file_exists($guardPath)) {
    require_once $guardPath; // carrega db.php e ensure_schema internamente
    if (!defined('EYEWEB_ROOT_GUARD_ACTIVE')) define('EYEWEB_ROOT_GUARD_ACTIVE', true);
    if (isset($EW_BOOT_LOG)) $EW_BOOT_LOG('guard included');
  }
} catch (Throwable $e) {
  // Não interromper o site EyeWeb caso a integração falhe
}

// Obter IP do cliente (considera proxy simples)
function eyeweb_client_ip() {
  $keys = ['HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
  foreach ($keys as $k) {
    if (!empty($_SERVER[$k])) {
      $ip = $_SERVER[$k];
      // X-Forwarded-For pode ter múltiplos IPs
      if ($k === 'HTTP_X_FORWARDED_FOR') {
        $parts = explode(',', $ip);
        $ip = trim($parts[0]);
      }
      // Normalizar loopback IPv6 para IPv4 por legibilidade
      if ($ip === '::1') { $ip = '127.0.0.1'; }
      return $ip;
    }
  }
  return '0.0.0.0';
}

// Conexão DB
// Se o guard já está ativo, não duplicar registos aqui
if (defined('EYEWEB_ROOT_GUARD_ACTIVE')) {
  if (isset($EW_BOOT_LOG)) $EW_BOOT_LOG('guard active - skip fallback');
  return; // o guard já fez bloqueio e registo
}

// Fallback 1: tentar registar visita via PDO (quando host é remoto e mysqli local não funciona)
try {
  $cfgPath = dirname(__DIR__) . '/security/config.php';
  if (file_exists($cfgPath)) {
    $cfg = require $cfgPath;
    $host = $cfg['db_host'] ?? 'localhost';
    if (!in_array($host, ['localhost','127.0.0.1','::1'], true)) {
      require_once dirname(__DIR__) . '/security/db.php';
      try { ensure_schema(); } catch (Throwable $e) {}
      $pdo = getPDO();
      // Cookie de dispositivo (mínimo, igual ao guard)
      $deviceId = $_COOKIE['device_id'] ?? null;
      if (!$deviceId) {
        try{ $deviceId = 'd_'.bin2hex(random_bytes(6)).'_'.dechex(time()); }catch(Throwable $e){ $deviceId='d_'.uniqid(); }
        @setcookie('device_id',$deviceId,['expires'=>time()+365*24*3600,'path'=>'/','samesite'=>'Lax']);
      }
      $ip = eyeweb_client_ip();
      $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
      $now = date('Y-m-d H:i:s');
      if (isset($EW_BOOT_LOG)) $EW_BOOT_LOG('fallback pdo insert attempt ip='.$ip.' device='.$deviceId);
      $stmt = $pdo->prepare('INSERT INTO visits (ip,user_agent,ts,blocked,notes,device_id,last_seen) VALUES (?,?,?,?,?,?,?)');
      $stmt->execute([$ip,$ua,$now,0,'eyeweb-fallback',$deviceId,$now]);
      if (isset($EW_BOOT_LOG)) $EW_BOOT_LOG('fallback pdo insert ok');
      return; // já registámos via PDO; não tentar mysqli
    }
  }
} catch (Throwable $e) {
  // Se falhar, continua para tentar mysqli local
  if (isset($EW_BOOT_LOG)) $EW_BOOT_LOG('fallback pdo error: '.$e->getMessage());
}

// Desativar exceptions do mysqli para evitar fatais em hosts com sockets indisponíveis
if (function_exists('mysqli_report')) { @mysqli_report(MYSQLI_REPORT_OFF); }

$conn = @new mysqli('localhost', 'root', '', 'eyeweb');
if ($conn && !$conn->connect_error) {
  // Garantir eventos do MySQL para agregação automática (sem worker)
  if (!defined('EYEWEB_EVENTS_CHECKED')) {
    define('EYEWEB_EVENTS_CHECKED', true);
    // Tenta ligar o event_scheduler (se permitido)
    @$conn->query("SET GLOBAL event_scheduler = ON");

    // Garante que as tabelas necessárias existem antes de criar eventos
    $conn->query("CREATE TABLE IF NOT EXISTS request_log (
      id INT NOT NULL AUTO_INCREMENT,
      ip VARCHAR(45) NOT NULL,
      method VARCHAR(10) DEFAULT NULL,
      uri VARCHAR(255) DEFAULT NULL,
      user_agent VARCHAR(255) DEFAULT NULL,
      bytes_in INT DEFAULT NULL,
      created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      INDEX idx_ts (created_at),
      INDEX idx_ip_ts (ip, created_at)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    $conn->query("CREATE TABLE IF NOT EXISTS active_connections (
      ip VARCHAR(45) NOT NULL,
      connections_5s INT NOT NULL DEFAULT 0,
      vpn_active TINYINT(1) NOT NULL DEFAULT 0,
      packets_5s INT NOT NULL DEFAULT 0,
      connections_total INT NOT NULL DEFAULT 0,
      packet_type VARCHAR(16) DEFAULT 'TCP',
      status ENUM('Segura','Suspeita','Maliciosa') DEFAULT 'Segura',
      last_seen TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (ip),
      INDEX idx_last_seen (last_seen)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    // garantir coluna connections_total (se faltava)
    $dbNameRes_ac0 = $conn->query('SELECT DATABASE() as db');
    $dbRow_ac0 = $dbNameRes_ac0 ? $dbNameRes_ac0->fetch_assoc() : null;
    $dbName_ac0 = $dbRow_ac0 ? $dbRow_ac0['db'] : 'eyeweb';
    if ($stmt_ac0 = $conn->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = "active_connections" AND COLUMN_NAME = "connections_total" LIMIT 1')) {
      $stmt_ac0->bind_param('s', $dbName_ac0);
      $stmt_ac0->execute();
      $stmt_ac0->store_result();
      $existsCT0 = $stmt_ac0->num_rows > 0;
      $stmt_ac0->close();
      if (!$existsCT0) { @$conn->query('ALTER TABLE `active_connections` ADD COLUMN `connections_total` INT NOT NULL DEFAULT 0 AFTER `packets_5s`'); }
    }

    $conn->query("CREATE TABLE IF NOT EXISTS suspicious_activity (
      id INT NOT NULL AUTO_INCREMENT,
      ip VARCHAR(45) NOT NULL,
      event VARCHAR(255) NOT NULL,
      severity ENUM('baixa','media','alta') NOT NULL DEFAULT 'baixa',
      created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      INDEX idx_ip_created (ip, created_at)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    // Cache local opcional para detecção de VPN/Proxy (preenchido por API/admin)
    $conn->query("CREATE TABLE IF NOT EXISTS vpn_cache (
      ip VARCHAR(45) NOT NULL PRIMARY KEY,
      is_vpn TINYINT(1) NOT NULL DEFAULT 0,
      provider VARCHAR(128) DEFAULT NULL,
      last_check TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");


    // Verifica se os eventos existem
    $dbNameRes = $conn->query('SELECT DATABASE() as db');
    $dbRow = $dbNameRes ? $dbNameRes->fetch_assoc() : null;
    $dbName = $dbRow ? $dbRow['db'] : 'eyeweb';

    // Recria SEMPRE o evento de atualização (garante que a última lógica está ativa)
    $conn->query("DROP EVENT IF EXISTS eyeweb_update_active_connections");
      $sqlEvent = "CREATE EVENT eyeweb_update_active_connections
        ON SCHEDULE EVERY 1 SECOND
        DO BEGIN
          -- Atualiza por segundo e acumula totais
     INSERT INTO active_connections (ip, connections_5s, vpn_active, packets_5s, connections_total, packet_type, status, last_seen)
     SELECT rl.ip,
       COUNT(*) as per_sec,
       COALESCE(vc.is_vpn, 0) as vpn_active,
       COUNT(*) as packets_init,
       COUNT(*) as conns_init,
       'TCP' as packet_type,
       'Segura' as status,
       NOW()
          FROM request_log rl
          LEFT JOIN vpn_cache vc ON vc.ip = rl.ip
          WHERE rl.created_at >= (NOW() - INTERVAL 1 SECOND)
          GROUP BY rl.ip
          ON DUPLICATE KEY UPDATE
            connections_5s = VALUES(connections_5s),
            packets_5s = IFNULL(active_connections.packets_5s,0) + VALUES(connections_5s),
            connections_total = IFNULL(active_connections.connections_total,0) + VALUES(connections_5s),
            status = CASE
                       WHEN (IFNULL(active_connections.packets_5s,0) + VALUES(connections_5s)) >= 500
                         OR (IFNULL(active_connections.connections_total,0) + VALUES(connections_5s)) >= 500
                         THEN 'Maliciosa'
                       WHEN VALUES(connections_5s) >= 6 THEN 'Maliciosa'
                       WHEN VALUES(connections_5s) >= 2 THEN 'Suspeita'
                       ELSE 'Segura'
                     END,
            last_seen = NOW();

          -- Zerar taxa por segundo para IPs ociosos
          UPDATE active_connections
          SET connections_5s = 0,
              status = CASE
                         WHEN packets_5s >= 500 OR connections_total >= 500 THEN 'Maliciosa'
                         WHEN packets_5s >= 100 OR connections_total >= 100 THEN 'Suspeita'
                         ELSE 'Segura'
                       END
          WHERE last_seen < (NOW() - INTERVAL 1 SECOND);

          -- Limpeza de inativos (1 hora sem atividade)
          DELETE FROM active_connections WHERE last_seen < (NOW() - INTERVAL 1 HOUR);
        END";
      @$conn->query($sqlEvent);

    // Recria SEMPRE o evento de atividade suspeita (mantém janela de 10s)
    $conn->query("DROP EVENT IF EXISTS eyeweb_insert_suspicious");
      $sqlEvent2 = "CREATE EVENT eyeweb_insert_suspicious
        ON SCHEDULE EVERY 1 SECOND
        DO BEGIN
          INSERT INTO suspicious_activity (ip, event, severity)
          SELECT t.ip,
                 CASE WHEN t.req_count >= 60 OR t.post_login >= 6 THEN 'Taxa elevada de pedidos' ELSE 'Atividade acima do normal' END as evt,
                 CASE WHEN t.req_count >= 60 OR t.post_login >= 6 THEN 'alta' ELSE 'media' END as sev
          FROM (
            SELECT ip,
                   COUNT(*) AS req_count,
                   SUM(CASE WHEN method='POST' AND (uri LIKE '%/login.php%' OR uri LIKE 'login.php%') THEN 1 ELSE 0 END) AS post_login
            FROM request_log
            WHERE created_at >= (NOW() - INTERVAL 10 SECOND)
            GROUP BY ip
          ) t
          WHERE (t.req_count >= 20 OR t.post_login >= 2)
            AND NOT EXISTS (
              SELECT 1 FROM suspicious_activity s
              WHERE s.ip = t.ip AND s.created_at >= (NOW() - INTERVAL 10 SECOND)
            );
        END";
      @$conn->query($sqlEvent2);
    
  }

  // Criar tabelas se não existirem
  $conn->query("CREATE TABLE IF NOT EXISTS request_log (
    id INT NOT NULL AUTO_INCREMENT,
    ip VARCHAR(45) NOT NULL,
    method VARCHAR(10) DEFAULT NULL,
    uri VARCHAR(255) DEFAULT NULL,
    user_agent VARCHAR(255) DEFAULT NULL,
    bytes_in INT DEFAULT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_ts (created_at),
    INDEX idx_ip_ts (ip, created_at)
  ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $conn->query("CREATE TABLE IF NOT EXISTS active_connections (
    ip VARCHAR(45) NOT NULL,
    connections_5s INT NOT NULL DEFAULT 0,
    vpn_active TINYINT(1) NOT NULL DEFAULT 0,
    packets_5s INT NOT NULL DEFAULT 0,
    connections_total INT NOT NULL DEFAULT 0,
    packet_type VARCHAR(16) DEFAULT 'TCP',
    status ENUM('Segura','Suspeita','Maliciosa') DEFAULT 'Segura',
    last_seen TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (ip),
    INDEX idx_last_seen (last_seen)
  ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Garantir coluna de total acumulado para bases existentes
  $dbNameRes_ac = $conn->query('SELECT DATABASE() as db');
  $dbRow_ac = $dbNameRes_ac ? $dbNameRes_ac->fetch_assoc() : null;
  $dbName_ac = $dbRow_ac ? $dbRow_ac['db'] : 'eyeweb';
  if ($stmt_ac = $conn->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = "active_connections" AND COLUMN_NAME = "connections_total" LIMIT 1')) {
    $stmt_ac->bind_param('s', $dbName_ac);
    $stmt_ac->execute();
    $stmt_ac->store_result();
    $existsCT = $stmt_ac->num_rows > 0;
    $stmt_ac->close();
    if (!$existsCT) {
      @$conn->query('ALTER TABLE `active_connections` ADD COLUMN `connections_total` INT NOT NULL DEFAULT 0 AFTER `packets_5s`');
    }
  }

  $conn->query("CREATE TABLE IF NOT EXISTS suspicious_activity (
    id INT NOT NULL AUTO_INCREMENT,
    ip VARCHAR(45) NOT NULL,
    event VARCHAR(255) NOT NULL,
    severity ENUM('baixa','media','alta') NOT NULL DEFAULT 'baixa',
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_ip_created (ip, created_at)
  ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $conn->query("CREATE TABLE IF NOT EXISTS blocked_ips (
    id INT NOT NULL AUTO_INCREMENT,
    ip VARCHAR(45) NOT NULL,
    reason VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    connections_at_block INT DEFAULT 0,
    packets_at_block INT DEFAULT 0,
    status_at_block VARCHAR(32) DEFAULT 'Bloqueado',
    packet_type_at_block VARCHAR(16) DEFAULT 'TCP',
    vpn_active_at_block TINYINT(1) DEFAULT 0,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_ip (ip)
  ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Garantir colunas de snapshot (para bases já existentes) sem usar IF NOT EXISTS
  $dbNameRes2 = $conn->query('SELECT DATABASE() as db');
  $dbRow2 = $dbNameRes2 ? $dbNameRes2->fetch_assoc() : null;
  $dbName2 = $dbRow2 ? $dbRow2['db'] : 'eyeweb';

  $ensureCol = function($col, $definition) use ($conn, $dbName2) {
    $exists = false;
    if ($stmt = $conn->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = "blocked_ips" AND COLUMN_NAME = ? LIMIT 1')) {
      $stmt->bind_param('ss', $dbName2, $col);
      $stmt->execute();
      $stmt->store_result();
      $exists = $stmt->num_rows > 0;
      $stmt->close();
    }
    if (!$exists) {
      $conn->query("ALTER TABLE `blocked_ips` ADD COLUMN `$col` $definition");
    }
  };

  $ensureCol('connections_at_block', 'INT DEFAULT 0');
  $ensureCol('packets_at_block', 'INT DEFAULT 0');
  $ensureCol('connections_total_at_block', 'INT DEFAULT 0');
  $ensureCol('status_at_block', "VARCHAR(32) DEFAULT 'Bloqueado'");
  $ensureCol('packet_type_at_block', "VARCHAR(16) DEFAULT 'TCP'");
  $ensureCol('vpn_active_at_block', 'TINYINT(1) DEFAULT 0');

  $ip = eyeweb_client_ip();
  $script = basename($_SERVER['SCRIPT_NAME'] ?? '');

  // Bypass do bloqueio: se for admin autenticado, ou páginas de login/logout
  $isAdmin = isset($_SESSION['user']) && $_SESSION['user'] === 'admin';
  $whitelistScripts = ['login.php', 'logout.php'];

  if (!$isAdmin && !in_array($script, $whitelistScripts, true)) {
    $stmt = $conn->prepare('SELECT 1 FROM blocked_ips WHERE ip = ? LIMIT 1');
    if ($stmt) {
      $stmt->bind_param('s', $ip);
      $stmt->execute();
      $stmt->store_result();
      if ($stmt->num_rows > 0) {
      // Bloqueado
      http_response_code(403);
      header('Content-Type: text/plain; charset=utf-8');
      echo 'Acesso bloqueado.';
      $stmt->close();
      $conn->close();
      exit();
      }
      $stmt->close();
    }
  }

  // Registo do pedido (não bloquear login/logout)
  $method = $_SERVER['REQUEST_METHOD'] ?? '';
  $uri = $_SERVER['REQUEST_URI'] ?? '';
  $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
  $bytesIn = isset($_SERVER['CONTENT_LENGTH']) ? intval($_SERVER['CONTENT_LENGTH']) : null;

  $stmt = $conn->prepare('INSERT INTO request_log (ip, method, uri, user_agent, bytes_in) VALUES (?, ?, ?, ?, ?)');
  if ($stmt) {
    $stmt->bind_param('ssssi', $ip, $method, $uri, $ua, $bytesIn);
    $stmt->execute();
    $stmt->close();
  }

  $conn->close();
}
?>