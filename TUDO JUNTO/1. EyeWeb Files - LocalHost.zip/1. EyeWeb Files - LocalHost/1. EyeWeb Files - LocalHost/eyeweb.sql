-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 18-Jun-2025 às 14:44
-- Versão do servidor: 9.1.0
-- versão do PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `eyeweb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `malicious_links`
--

DROP TABLE IF EXISTS `malicious_links`;
CREATE TABLE IF NOT EXISTS `malicious_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `url` text NOT NULL,
  `phishing` tinyint(1) DEFAULT '0',
  `insecure` tinyint(1) DEFAULT '0',
  `coleta` tinyint(1) DEFAULT '0',
  `attack_type` varchar(255) DEFAULT NULL,
  `attack_date` date DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `malicious_links`
--

INSERT INTO `malicious_links` (`id`, `url`, `phishing`, `insecure`, `coleta`, `attack_type`, `attack_date`, `submitted_at`) VALUES
(1, 'https://www.teste.com', 1, 0, 1, 'DDOS', '2025-06-17', '2025-06-17 21:30:19'),
(2, 'https://www.teste2.com', 1, 1, 1, '', '0000-00-00', '2025-06-17 21:31:13'),
(3, 'https://www.teste3.com', 0, 0, 0, 'DOS', '2025-04-25', '2025-06-17 21:34:28'),
(4, 'https://www.teste4.com', 1, 1, 1, 'RPD e MItM', '2025-06-18', '2025-06-18 01:38:20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_data`
--

DROP TABLE IF EXISTS `password_data`;
CREATE TABLE IF NOT EXISTS `password_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` text NOT NULL,
  `category` enum('fraca','media','forte') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `password_data`
--

INSERT INTO `password_data` (`id`, `password`, `category`, `created_at`) VALUES
(1, '123', 'forte', '2025-06-17 21:34:54'),
(2, 'istec', 'forte', '2025-06-18 01:38:44'),
(3, '1234', 'forte', '2025-06-18 01:38:54'),
(4, 'admin', 'forte', '2025-06-18 01:39:06');

-- --------------------------------------------------------

--
-- Estrutura da tabela `personal_data`
--

DROP TABLE IF EXISTS `personal_data`;
CREATE TABLE IF NOT EXISTS `personal_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `personal_data`
--

INSERT INTO `personal_data` (`id`, `name`, `phone`, `email`, `created_at`) VALUES
(8, 'Rita', 'Sem informação', 'cubcgames@gmail.com', '2025-06-17 21:33:55'),
(6, 'Samuel', 'Sem informação', '1samuelrocha@gmail.com', '2025-06-17 21:25:16'),
(10, 'Hacker', '912361779', 'cubcgames@gmail.com', '2025-06-18 00:34:08'),
(11, 'Samuel', '912456784', 'rochaoliveira01@gmail.com', '2025-06-18 01:37:40');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', '123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
