<?php
session_start();

$tempoInativo = 600;

if (!isset($_SESSION['user'])) {
  header('Location: login.php');
  exit();
}

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $tempoInativo)) {
  session_unset();
  session_destroy();
  header('Location: login.php');
  exit();
}
$_SESSION['last_activity'] = time();

// CORRIGIDO: ligação ao InfinityFree
$conn = new mysqli('localhost', 'root', '', 'eyeweb');
if ($conn->connect_error) {
  die('Erro na ligação: ' . $conn->connect_error);
}

// PROCESSAR DADOS PESSOAIS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['form-type'] === 'personal') {
  $name  = $_POST['name'] ?? 'Sem informação';
  $phone = $_POST['phone'] ?? 'Sem informação';
  $email = $_POST['email'] ?? 'Sem informação';

  $stmt = $conn->prepare("INSERT INTO personal_data (name, phone, email) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $name, $phone, $email);
  $stmt->execute();
  $stmt->close();

  $_SESSION['success_message'] = "Dados pessoais guardados com sucesso!";
  header("Location: admin.php#sec-personal");
  exit();
}

// PROCESSAR LINK MALICIOSO
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['form-type'] === 'link') {
  $url         = $_POST['url'] ?? '';
  $phishing    = isset($_POST['phishing']) ? 1 : 0;
  $insecure    = isset($_POST['insecure']) ? 1 : 0;
  $coleta      = isset($_POST['coleta']) ? 1 : 0;
  $attack_type = $_POST['attack_type'] ?? null;
  $attack_date = $_POST['attack_date'] ?? null;

  $stmt = $conn->prepare("INSERT INTO malicious_links (url, phishing, insecure, coleta, attack_type, attack_date) VALUES (?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("siiiss", $url, $phishing, $insecure, $coleta, $attack_type, $attack_date);
  $stmt->execute();
  $stmt->close();

  $_SESSION['success_message_links'] = "Link malicioso registado com sucesso!";
  header("Location: admin.php#sec-links");
  exit();
}


// PROCESSAR PASSWORDS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['form-type'] === 'password') {
  $password = $_POST['password'] ?? '';
  $category = $_POST['category'] ?? 'fraca';

  $stmt = $conn->prepare("INSERT INTO password_data (password, category) VALUES (?, ?)");
  $stmt->bind_param("ss", $password, $category);
  $stmt->execute();
  $stmt->close();

  $_SESSION['success_message_password'] = "Password registada com sucesso!";
  header("Location: admin.php#sec-password");
  exit();
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>EyeWeb Admin</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">

 <nav class="navbar">
   <a href="admin.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
    <a href="admin.php" class="nav-link active">Add Data</a>
    <a href="admin_data_base.php" class="nav-link">View Data</a>

    <a class="nav-icon" id="user-icon" title="Login">
      <i class="fa-solid fa-user"></i>
    </a>

    <div id="user-popup" class="user-popup hide">
      <p>User: Admin</p>
      <a href="logout.php" title="Sair">
        <i class="fa-solid fa-right-from-bracket logout-icon"></i>
      </a>
    </div>
   </div>
 </nav>

  <header class="header container">
    <h1>Admin Dashboard</h1>
  </header>

  <main class="container">
    <nav class="admin-tabs">
      <button class="admin-tab active" data-sec="sec-personal">Dados Pessoais</button>
      <button class="admin-tab" data-sec="sec-links">Verificação de Links</button>
      <button class="admin-tab" data-sec="sec-password">Passwords</button>
    </nav>

    <!-- DADOS PESSOAIS -->
    <section id="sec-personal" class="admin-section">
      <?php
      if (isset($_SESSION['success_message'])) {
        echo "<p style='color:limegreen;'>" . $_SESSION['success_message'] . "</p>";
        unset($_SESSION['success_message']);
      }
      ?>
      <form method="post">
        <input type="hidden" name="form-type" value="personal">

        <div class="form-group">
          <label for="name-input">Nome</label>
          <input id="name-input" name="name" type="text">
          <label class="inline">
            <input type="checkbox" class="not-found" data-target="name-input">
            Não encontrado
          </label>
        </div>

        <div class="form-group">
          <label for="phone-input">Telemóvel</label>
          <input id="phone-input" name="phone" type="tel">
          <label class="inline">
            <input type="checkbox" class="not-found" data-target="phone-input">
            Não encontrado
          </label>
        </div>

        <div class="form-group">
          <label for="email-input">Email</label>
          <input id="email-input" name="email" type="email">
          <label class="inline">
            <input type="checkbox" class="not-found" data-target="email-input">
            Não encontrado
          </label>
        </div>

        <button type="submit">Enviar</button>
      </form>
    </section>

    <!-- VERIFICAÇÃO DE LINKS -->
    <section id="sec-links" class="admin-section hide">
    <?php
if (isset($_SESSION['success_message_links'])) {
  echo "<p style='color:limegreen;'>" . $_SESSION['success_message_links'] . "</p>";
  unset($_SESSION['success_message_links']);
}
?>
<form method="post">
  <input type="hidden" name="form-type" value="link">

  <div class="form-group">
    <label for="link-input">Link</label>
    <input id="link-input" name="url" type="url" required>
  </div>

  <fieldset class="vertical">
    <legend>Problemas Detectados</legend>
    <label><input type="checkbox" name="phishing" class="square-checkbox"> Phishing</label>
    <label><input type="checkbox" name="insecure" class="square-checkbox"> Ligação insegura</label>
    <label><input type="checkbox" name="coleta" class="square-checkbox"> Coleta não autorizada</label>
  </fieldset>

  <fieldset>
    <legend>Ataques</legend>
    <label><input type="radio" name="ataque" value="no" checked> Não</label>
    <label><input type="radio" name="ataque" value="yes"> Sim</label>
    <div id="attack-details" class="hide">
      <div class="form-group">
        <label for="attack-type">Tipo de Ataque</label>
        <input id="attack-type" name="attack_type" type="text">
      </div>
      <div class="form-group">
        <label for="attack-date">Data</label>
        <input id="attack-date" name="attack_date" type="date">
      </div>
    </div>
  </fieldset>

  <button type="submit">Enviar</button>
</form>
    </section>

<!-- PASSWORDS -->
<section id="sec-password" class="admin-section hide">
  <?php
  if (isset($_SESSION['success_message_password'])) {
    echo "<p style='color:limegreen;'>" . $_SESSION['success_message_password'] . "</p>";
    unset($_SESSION['success_message_password']);
  }
  ?>
  <form method="post">
    <input type="hidden" name="form-type" value="password">

    <div class="form-group">
      <label for="password-input">Password</label>
      <input id="password-input" name="password" type="password" required>
    </div>

    <div class="vuln-group">
      <label for="vuln-select">Categoria de Vulnerabilidade</label>
      <select id="vuln-select" name="category" required>
        <option value="fraca">Fraca</option>
        <option value="media">Média</option>
        <option value="forte">Forte</option>
      </select>
    </div>

    <button type="submit">Enviar</button>
  </form>
</section>

  </main>

  <script src="js/admin.js"></script>
</body>
</html>
