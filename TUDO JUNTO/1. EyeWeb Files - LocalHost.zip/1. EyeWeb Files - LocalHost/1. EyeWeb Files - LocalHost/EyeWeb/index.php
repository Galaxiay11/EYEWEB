<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

if (isset($_SESSION['user'])) {
  session_unset();
  session_destroy();
}

$mysqli = new mysqli("localhost", "root", "", "eyeweb");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$resultData = null;
$mensagemPersonalizada = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['type']) && isset($_POST['query'])) {
        $type = $_POST['type'];
        $query = trim($_POST['query']);

        if ($type === 'email') {
            $stmt = $mysqli->prepare("SELECT * FROM personal_data WHERE email = ?");
            $stmt->bind_param("s", $query);
            $stmt->execute();
            $result = $stmt->get_result();
            $resultData = $result->fetch_assoc();
            if (!$resultData) {
                $mensagemPersonalizada = 'Tudo em ordem! Dados não encontrados na nossa base de dados';
            }
        } elseif ($type === 'phone') {
            $stmt = $mysqli->prepare("SELECT * FROM personal_data WHERE phone = ?");
            $stmt->bind_param("s", $query);
            $stmt->execute();
            $result = $stmt->get_result();
            $resultData = $result->fetch_assoc();
            if (!$resultData) {
                $mensagemPersonalizada = 'Tudo em ordem! Dados não encontrados na nossa base de dados';
            }
        } elseif ($type === 'url') {
            $stmt = $mysqli->prepare("SELECT * FROM malicious_links WHERE url LIKE ?");
            $searchUrl = '%' . $query . '%';
            $stmt->bind_param("s", $searchUrl);
            $stmt->execute();
            $result = $stmt->get_result();
            $urlData = $result->fetch_assoc();

            if ($urlData) {
                $problemas = [];
                if ($urlData['phishing']) $problemas[] = "Phishing";
                if ($urlData['insecure']) $problemas[] = "Inseguro";
                if ($urlData['coleta']) $problemas[] = "Coleta de Dados";

                $resultData = [
                    'status' => 'dangerous',
                    'message' => 'URL maliciosa encontrada!',
                    'problemas' => !empty($problemas) ? implode(" / ", $problemas) : "Nenhum problema específico detectado",
                    'ataque' => $urlData['attack_type'] ?? "Tipo de ataque não especificado",
                    'data_ataque' => $urlData['attack_date'] ? date('d/m/Y', strtotime($urlData['attack_date'])) : "Data não disponível"
                ];
            } else {
                $resultData = [
                    'status' => 'safe' // Mensagem removida aqui
                ];
            }
        } elseif ($type === 'password') {
            $stmt = $mysqli->prepare("SELECT * FROM password_data WHERE password = ?");
            $stmt->bind_param("s", $query);
            $stmt->execute();
            $result = $stmt->get_result();
            $passData = $result->fetch_assoc();

            if ($passData) {
                $messages = [
                    'fraca' => [
                        'class' => 'safe',
                        'message' => 'Esta senha não foi encontrada em vazamentos conhecidos',
                        'advice' => '✅ Esta senha parece segura contra vazamentos conhecidos'
                    ],
                    'media' => [
                        'class' => 'warning',
                        'message' => 'Esta senha foi encontrada em alguns vazamentos',
                        'advice' => '🔸 Esta senha apareceu em alguns vazamentos - considere alterá-la'
                    ],
                    'forte' => [
                        'class' => 'danger',
                        'message' => 'Esta senha foi amplamente comprometida em vazamentos',
                        'advice' => '⚠️ Esta senha está altamente comprometida - NÃO USE!'
                    ]
                ];

                $resultData = [
                    'status' => $messages[$passData['category']]['class'],
                    'message' => $messages[$passData['category']]['message'],
                    'advice' => $messages[$passData['category']]['advice'],
                    'strength' => $passData['category']
                ];
            } else {
                $resultData = [
                    'status' => 'unknown',
                    'message' => 'Senha não encontrada na base de dados',
                    'advice' => 'Esta senha não foi encontrada em nossos registros de vazamentos',
                    'strength' => 'unknown'
                ];
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EyeWeb</title>
  <link rel="stylesheet" href="css/index.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">

  <div class="eye-screen">
    <div class="eye-container" id="eyeContainer"><div class="eye"><div class="pupil"></div></div></div>
  </div>

  <div id="afterClick" class="after-click hidden">
    <nav class="navbar">
      <a href="index.php" class="logo-text">EyeWeb</a>
      <div class="navbar-right">
        <a href="about.php" class="nav-link">About</a>
        <a href="login.php" class="nav-icon" title="Login"><i class="fa-solid fa-user"></i></a>
      </div>
    </nav>

    <header class="header container"><h1>EyeWeb</h1></header>

    <main class="container">
      <p class="tagline">Analise emails, URLs e passwords para detetar vazamentos, malwares e ataques.</p>

      <nav class="tabs">
        <button class="tab active" data-target="tab-personal">PERSONAL DATA</button>
        <button class="tab" data-target="tab-url">URL CHECK</button>
        <button class="tab" data-target="tab-password">PASSWORD CHECK</button>
      </nav>

      <!-- PERSONAL DATA -->
      <section id="tab-personal" class="tab-content">
        <div class="card">
          <div class="tab-buttons">
            <button data-type="email" class="active">Email</button>
            <button data-type="phone">Phone</button>
          </div>
          <input type="text" id="personal-input" placeholder="Verifique o email">
          <button id="personal-search">Search</button>
          <div id="personal-result" class="result">
            <?php if (isset($_POST['type']) && ($_POST['type'] === 'email' || $_POST['type'] === 'phone')): ?>
              <div class="result-container">
                <?php if (!empty($resultData)): ?>
                  <h3><?= htmlspecialchars(ucfirst($_POST['type'])) ?> encontrado</h3>
                  <div class="related-data">
                    <?php if (isset($resultData['name'])): ?>
                      <p><strong>Nome:</strong> <?= htmlspecialchars($resultData['name']) ?></p>
                    <?php endif; ?>
                    <?php if (isset($resultData['email'])): ?>
                      <p><strong>Email:</strong> <?= htmlspecialchars($resultData['email']) ?></p>
                    <?php endif; ?>
                    <?php if (isset($resultData['phone'])): ?>
                      <p><strong>Número:</strong> <?= htmlspecialchars($resultData['phone']) ?></p>
                    <?php endif; ?>
                  </div>
                <?php else: ?>
                  <p class="success"><?= $mensagemPersonalizada ?></p>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </section>

      <!-- URL CHECK -->
      <section id="tab-url" class="tab-content hide">
        <div class="card">
          <input type="url" id="link-input" placeholder="Adicione o link que quer verificar">
          <button id="link-search">Check Link</button>
          <div id="link-result" class="result">
            <?php if ($resultData && isset($_POST['type']) && $_POST['type'] === 'url'): ?>
              <div class="result-container">
                <h3>Resultado da Verificação de URL</h3>
                <div class="status-badge <?= $resultData['status'] === 'dangerous' ? 'danger' : 'safe' ?>">
                  <?= strtoupper($resultData['status']) ?>
                </div>
                <?php if (isset($resultData['message'])): ?>
                  <p><?= htmlspecialchars($resultData['message']) ?></p>
                <?php endif; ?>
                <?php if ($resultData['status'] === 'dangerous'): ?>
                  <div class="url-details">
                    <h4>Problemas Detectados:</h4>
                    <p><?= htmlspecialchars($resultData['problemas']) ?></p>
                    <h4>Ataques realizados:</h4>
                    <p><?= htmlspecialchars($resultData['ataque']) ?></p>
                    <h4>Data do ataque:</h4>
                    <p><?= htmlspecialchars($resultData['data_ataque']) ?></p>
                  </div>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </section>

      <!-- PASSWORD CHECK -->
      <section id="tab-password" class="tab-content hide">
        <div class="card">
          <input type="text" id="password-input" placeholder="Verifique a sua password">
          <button id="password-search">Verify Password</button>
          <div id="password-result" class="result">
            <?php if ($resultData && isset($_POST['type']) && $_POST['type'] === 'password'): ?>
              <div class="result-container">
                <h3>Resultado da verificação de senha</h3>
                <div class="status-badge <?= $resultData['status'] ?>">
                  <?= strtoupper($resultData['status']) ?>
                </div>
                <p><?= htmlspecialchars($resultData['message']) ?></p>
                <p class="password-<?= $resultData['strength'] ?>">
                  <?= htmlspecialchars($resultData['advice']) ?>
                </p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </section>
    </main>
  </div>

  <script src="js/index.js"></script>
</body>
</html>
