<?php
session_start();

// Se veio do admin e existe sessão, destrói-a
if (isset($_SESSION['user'])) {
  session_unset();
  session_destroy();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>About — EyeWeb</title>
  <link rel="stylesheet" href="css/about.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">


   <nav class="navbar">
   <a href="index.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
     <a href="about.php" class="nav-link">About</a>
     <a href="login.php" class="nav-icon" title="Login">
       <i class="fa-solid fa-user"></i>
     </a>
   </div>
 </nav>

  <header class="header container">
    <h1>About EyeWeb</h1>
    <nav class="about-nav">
      <a href="#mission">Missão</a>
      <a href="#vision">Visão</a>
      <a href="#team">Equipa</a>
    </nav>
  </header>

  <main class="container">
    <!-- Missão -->
    <section id="mission" class="about-section">
      <h2>Missão</h2>
      <p>
         Somos uma equipa dedicada à cibersegurança, empenhada no desenvolvimento de um projeto inovador 
         com o objetivo de tornar a Internet um espaço mais seguro. A nossa missão centra-se na disponibilização 
         de ferramentas de verificação acessíveis, intuitivas e eficazes, permitindo a todos os utilizadores, independentemente 
         do seu nível de conhecimento, protegerem-se contra ameaças digitais de forma autónoma e informada.
      </p>
    </section>

    <!-- Visão -->
    <section id="vision" class="about-section">
      <h2>Visão</h2>
      <p>
         Ambicionamos um futuro em que qualquer pessoa, desde o utilizador menos experiente até ao profissional especializado 
         tenha à sua disposição meios simples e imediatos para verificar a reputação de links, ficheiros, palavras-passe e dados pessoais.
         Pretendemos contribuir decisivamente para a redução do número de ataques cibernéticos bem-sucedidos e de incidentes de violação de dados,
         promovendo uma cultura de segurança digital acessível e eficaz.
      </p>
    </section>

    <!-- Equipa -->
    <section id="team" class="about-section">
      <h2>Equipa</h2>
      <ul class="team-list">
        <li>
          <strong>Ana Rita</strong> — Galaxiay11
          <em>Product Owner, Desenvolvimento da interface, documentação e líder do grupo.</em>
        </li>
        <li>
          <strong>José Oliveira</strong> — Wodash34  
          <em>Desenvolvimento do frontend, design gráfico, base de dados</em>
        </li>
        <li>
          <strong>Tiago Carvalho</strong> — Tiago0612  
          <em>Backend, diagrama ER, base de dados</em>
        </li>
        <li>
          <strong>Vanina Kollen</strong> — vankol06 
          <em>Estruturação da base de dados, backend, relatório técnico</em>
        </li>
         <li>
           <strong>Francisco Ribeiro</strong> — Xico20230  
          <em>Funcionalidades, apoio técnico geral </em>
        </li>
         <li>
          <strong>Emanuel Barbosa</strong> — 
          <em> Relatório técnico, estrutura da informação</em>
        </li>
      </ul>
    </section>

    <!-- Tecnologias -->
    <section id="tech" class="about-section">
      <h2>Tecnologias</h2>
      <ul>
        <li>Backend: PHP</li>
        <li>Frontend: HTML, CSS, JavaScript</li>
        <li>Banco de dados: MySQL (arquivo SQL fornecido)</li>
        <li>Servidor local: WAMP Server (Windows, Apache, MySQL, PHP)</li>
      </ul>
    </section>

  </main>

  <footer class="footer container">
    <small>© 2025 EyeWeb — Todos os direitos reservados</small>
  </footer>

<script type="module" src="js/about.js"></script>
</body>
</html>