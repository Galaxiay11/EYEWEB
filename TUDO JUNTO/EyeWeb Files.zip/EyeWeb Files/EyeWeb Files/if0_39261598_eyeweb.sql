-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql106.byetcluster.com
-- Tempo de geração: 18-Jun-2025 às 10:38
-- Versão do servidor: 10.6.19-MariaDB
-- versão do PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `if0_39261598_eyeweb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `malicious_links`
--

CREATE TABLE `malicious_links` (
  `id` int(11) NOT NULL,
  `url` text NOT NULL,
  `phishing` tinyint(1) DEFAULT 0,
  `insecure` tinyint(1) DEFAULT 0,
  `coleta` tinyint(1) DEFAULT 0,
  `attack_type` varchar(255) DEFAULT NULL,
  `attack_date` date DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `malicious_links`
--

INSERT INTO `malicious_links` (`id`, `url`, `phishing`, `insecure`, `coleta`, `attack_type`, `attack_date`, `submitted_at`) VALUES
(1, 'https://www.teste.com', 1, 0, 1, 'DDOS', '2025-06-17', '2025-06-17 21:30:19'),
(2, 'https://www.teste2.com', 1, 1, 1, '', '0000-00-00', '2025-06-17 21:31:13'),
(3, 'https://www.teste3.com', 0, 0, 0, 'DOS', '2025-04-25', '2025-06-17 21:34:28'),
(4, 'https://www.teste4.com', 1, 1, 1, 'RPD e MItM', '2025-06-18', '2025-06-18 01:38:20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_data`
--

CREATE TABLE `password_data` (
  `id` int(11) NOT NULL,
  `password` text NOT NULL,
  `category` enum('fraca','media','forte') NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `password_data`
--

INSERT INTO `password_data` (`id`, `password`, `category`, `created_at`) VALUES
(1, '1234', 'forte', '2025-06-17 21:34:54'),
(2, 'istec', 'forte', '2025-06-18 01:38:44'),
(3, '12345', 'forte', '2025-06-18 01:38:54'),
(4, 'admin', 'forte', '2025-06-18 01:39:06'),
(5, 'admin123', 'forte', '2025-06-18 11:05:37');

-- --------------------------------------------------------

--
-- Estrutura da tabela `personal_data`
--

CREATE TABLE `personal_data` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `personal_data`
--

INSERT INTO `personal_data` (`id`, `name`, `phone`, `email`, `created_at`) VALUES
(12, 'Rita', '345681223', 'rita@gmail.com', '2025-06-18 13:41:37'),
(13, 'Samuka', 'Sem informaÃ§Ã£o', 'samuka@gmail.com', '2025-06-18 13:51:50'),
(11, 'Samuel', '912456784', 'rochaoliveira01@gmail.com', '2025-06-18 01:37:40');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', '123');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `malicious_links`
--
ALTER TABLE `malicious_links`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `password_data`
--
ALTER TABLE `password_data`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `personal_data`
--
ALTER TABLE `personal_data`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `malicious_links`
--
ALTER TABLE `malicious_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `password_data`
--
ALTER TABLE `password_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `personal_data`
--
ALTER TABLE `personal_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
