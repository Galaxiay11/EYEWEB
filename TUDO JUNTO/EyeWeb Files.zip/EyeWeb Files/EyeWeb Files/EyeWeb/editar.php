<?php
session_start();

if (!isset($_SESSION['user'])) {
  header('Location: login.php');
  exit();
}

// Ligação à base de dados REMOTA
$conn = new mysqli('sql106.infinityfree.com', 'if0_39261598', 'UO9jt5N3Z2GpvV', 'if0_39261598_eyeweb');
if ($conn->connect_error) {
  die("Erro na conexão: " . $conn->connect_error);
}

// Validação de parâmetros e proteção contra SQL injection
if (!isset($_GET['id'], $_GET['table'])) {
  header('Location: admin_data_base.php');
  exit();
}

$id = intval($_GET['id']); // segurança: força para inteiro
$table = $_GET['table'];

$allowedTables = ['personal_data', 'malicious_links', 'password_data'];
if (!in_array($table, $allowedTables)) {
  die("Tabela inválida.");
}

// Obter dados atuais do registo
$stmt = $conn->prepare("SELECT * FROM $table WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  header('Location: admin_data_base.php');
  exit();
}

$row = $result->fetch_assoc();

// Processar submissão do formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  switch ($table) {
    case 'personal_data':
      $name = $_POST['name'] ?? 'Sem informação';
      $phone = $_POST['phone'] ?? 'Sem informação';
      $email = $_POST['email'] ?? 'Sem informação';

      $stmt = $conn->prepare("UPDATE personal_data SET name = ?, phone = ?, email = ? WHERE id = ?");
      $stmt->bind_param("sssi", $name, $phone, $email, $id);
      break;

    case 'malicious_links':
      $url = $_POST['url'] ?? '';
      $phishing = isset($_POST['phishing']) ? 1 : 0;
      $insecure = isset($_POST['insecure']) ? 1 : 0;
      $coleta = isset($_POST['coleta']) ? 1 : 0;
      $attack_type = $_POST['attack_type'] ?? null;
      $attack_date = $_POST['attack_date'] ?? null;

      $stmt = $conn->prepare("UPDATE malicious_links SET url = ?, phishing = ?, insecure = ?, coleta = ?, attack_type = ?, attack_date = ? WHERE id = ?");
      $stmt->bind_param("siiissi", $url, $phishing, $insecure, $coleta, $attack_type, $attack_date, $id);
      break;

    case 'password_data':
      $password = $_POST['password'] ?? '';
      $category = $_POST['category'] ?? 'fraca';

      $stmt = $conn->prepare("UPDATE password_data SET password = ?, category = ? WHERE id = ?");
      $stmt->bind_param("ssi", $password, $category, $id);
      break;
  }

  if ($stmt->execute()) {
    $_SESSION['success_message'] = "Registo atualizado com sucesso!";
  } else {
    $_SESSION['error_message'] = "Erro ao atualizar o registo.";
  }

  header("Location: admin_data_base.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Editar Registo - EyeWeb Admin</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">

 <nav class="navbar">
   <a href="admin.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
    <a href="admin.php" class="nav-link">Add Data</a>
    <a href="admin_data_base.php" class="nav-link">View Data</a>

    <a class="nav-icon" id="user-icon" title="Login">
      <i class="fa-solid fa-user"></i>
    </a>

    <div id="user-popup" class="user-popup hide">
      <p>User: Admin</p>
      <a href="logout.php" title="Sair">
        <i class="fa-solid fa-right-from-bracket logout-icon"></i>
      </a>
    </div>
   </div>
 </nav>

  <header class="header container">
     <h1>Editar Registo</h1>
    <h2>Tabela: <?= htmlspecialchars($table) ?></h2>
  </header>

<main class="container">
  <form method="post">
    <?php if ($table === 'personal_data'): ?>
      <div class="form-group">
        <label for="name">Nome</label>
        <input id="name" name="name" type="text" value="<?= htmlspecialchars($row['name']) ?>">
      </div>
      
      <div class="form-group">
        <label for="phone">Telemóvel</label>
        <input id="phone" name="phone" type="tel" value="<?= htmlspecialchars($row['phone']) ?>">
      </div>
      
      <div class="form-group">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" value="<?= htmlspecialchars($row['email']) ?>">
      </div>
      
    <?php elseif ($table === 'malicious_links'): ?>
      <div class="form-group">
        <label for="url">URL</label>
        <input id="url" name="url" type="url" value="<?= htmlspecialchars($row['url']) ?>" required>
      </div>
      
      <fieldset class="vertical">
        <legend>Problemas Detectados</legend>
        <label><input type="checkbox" name="phishing" class="square-checkbox" <?= $row['phishing'] ? 'checked' : '' ?>> Phishing</label>
        <label><input type="checkbox" name="insecure" class="square-checkbox" <?= $row['insecure'] ? 'checked' : '' ?>> Ligação insegura</label>
        <label><input type="checkbox" name="coleta" class="square-checkbox" <?= $row['coleta'] ? 'checked' : '' ?>> Coleta não autorizada</label>
      </fieldset>
      
      <div class="form-group">
        <label for="attack_type">Tipo de Ataque</label>
        <input id="attack_type" name="attack_type" type="text" value="<?= htmlspecialchars($row['attack_type']) ?>">
      </div>
      
      <div class="form-group">
        <label for="attack_date">Data do Ataque</label>
        <input id="attack_date" name="attack_date" type="date" value="<?= htmlspecialchars($row['attack_date']) ?>">
      </div>
      
    <?php elseif ($table === 'password_data'): ?>
      <div class="form-group">
        <label for="password">Password</label>
        <input id="password" name="password" type="text" value="<?= htmlspecialchars($row['password']) ?>" required>
      </div>
      
      <div class="vuln-group">
        <label for="category">Categoria</label>
        <select id="category" name="category" required>
          <option value="fraca" <?= $row['category'] === 'fraca' ? 'selected' : '' ?>>Fraca</option>
          <option value="media" <?= $row['category'] === 'media' ? 'selected' : '' ?>>Média</option>
          <option value="forte" <?= $row['category'] === 'forte' ? 'selected' : '' ?>>Forte</option>
        </select>
      </div>
    <?php endif; ?>
    
   <div class="form-buttons">
      <button type="submit">Guardar Alterações</button>
      <a href="admin_data_base.php" class="back-button">Cancelar</a>
    </div>
  </form>
</main>

<script src="js/admin.js"></script>
</body>
</html>
<?php
$conn->close();
?>