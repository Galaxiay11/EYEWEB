document.addEventListener('DOMContentLoaded', () => {
  const eyeContainer = document.getElementById('eyeContainer');
  const pupil = eyeContainer.querySelector('.pupil');
  const afterClick = document.getElementById('afterClick');
  const eyeScreen = document.querySelector('.eye-screen');

  // Usar sessionStorage para apagar ao fechar o navegador
  const alreadySeen = sessionStorage.getItem('eyeSeen');

  if (alreadySeen === 'true') {
    eyeScreen.remove();
    afterClick.classList.remove('hidden');
    afterClick.classList.add('show');
    document.body.style.overflow = 'auto';
    return;
  }

  function onMouseMove(e) {
    const rect = eyeContainer.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX);
    const maxDistance = 25;
    const distance = Math.min(maxDistance, Math.hypot(e.clientX - centerX, e.clientY - centerY) / 5);

    pupil.style.transform = `translate(-50%, -50%) translate(${Math.cos(angle) * distance}px, ${Math.sin(angle) * distance}px)`;
  }

  document.addEventListener('mousemove', onMouseMove);

  eyeContainer.addEventListener('click', () => {
    document.removeEventListener('mousemove', onMouseMove);
    pupil.style.transform = 'translate(-50%, -50%)';
    eyeContainer.classList.add('clicked');

    // Salvar no sessionStorage (será apagado automaticamente ao fechar o navegador)
    sessionStorage.setItem('eyeSeen', 'true');

    setTimeout(() => {
      eyeScreen.remove();
      afterClick.classList.remove('hidden');
      afterClick.classList.add('show');
      document.body.style.overflow = 'auto';
    }, 3000);
  });

});

// Tabs
const tabs = document.querySelectorAll('.tab');
const contents = document.querySelectorAll('.tab-content');
const linkResult = document.getElementById('link-result');
const passwordResult = document.getElementById('password-result');
const linkInput = document.getElementById('link-input');
const passwordInput = document.getElementById('password-input');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    // Limpa todos os resultados e campos de input quando muda de aba
    personalResult.innerHTML = '';
    linkResult.innerHTML = '';
    passwordResult.innerHTML = '';
    personalInput.value = '';
    linkInput.value = '';
    passwordInput.value = '';
    
    // Restante da lógica original das tabs
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    contents.forEach(c => c.classList.add('hide'));
    document.getElementById(tab.dataset.target).classList.remove('hide');
  });
});

// Botões de dados pessoais
const personalBtns = document.querySelectorAll('.tab-buttons button');
const personalInput = document.getElementById('personal-input');
const personalResult = document.getElementById('personal-result');
personalBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    personalBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const type = btn.dataset.type;
    // Alterado para os textos em português conforme solicitado
    personalInput.placeholder = type === 'email' ? 'Verifique o email' : 'Verifique o telemóvel';
    personalInput.value = ''; // Limpa o campo de entrada ao alternar
    personalResult.innerHTML = ''; // Limpa os resultados da pesquisa
  });
});

// Stubs de resultados
document.getElementById('personal-search').addEventListener('click', () => {
  document.getElementById('personal-result').textContent =
    'Found leak on 2024-11-03 in leaked_data_001.txt';
});
document.getElementById('password-search').addEventListener('click', () => {
  document.getElementById('password-result').textContent =
    'Password strength: Weak (found in 10 leaks)';
});

document.addEventListener('DOMContentLoaded', function() {
// Personal data search
document.getElementById('personal-search').addEventListener('click', function() {
  const activeTab = document.querySelector('.tab-buttons button.active');
  const type = activeTab.getAttribute('data-type');
  const query = document.getElementById('personal-input').value.trim();
  const personalResult = document.getElementById('personal-result');
  
  // Validação para campo vazio
  if (!query) {
    personalResult.innerHTML = `
      <div class="result-container">
        <p class="suggestion">Por favor, preencha o campo de ${type}</p>
      </div>
    `;
    return;
  }

// Validação específica para email
if (type === 'email') {
  const emailRegex = /^[^\s@]+@gmail\.com$/i; // Verifica especificamente @gmail.com
  if (!emailRegex.test(query)) {
    personalResult.innerHTML = `
      <div class="result-container">
        <p class="suggestion">Por favor, insira um email válido do Gmail (exemplo@gmail.com)</p>
      </div>
    `;
    return;
  }
}
  
  // Validação específica para telefone (ajuste conforme o formato desejado)
  if (type === 'phone') {
    const phoneRegex = /^[0-9]{9}$/; // Ajuste para o formato de telefone que desejar
    if (!phoneRegex.test(query)) {
      personalResult.innerHTML = `
        <div class="result-container">
          <p class="suggestion">Por favor, insira um número de telemóvel válido (9 digitos)</p>
        </div>
      `;
      return;
    }
  }
  
  fetch('index.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `type=${encodeURIComponent(type)}&query=${encodeURIComponent(query)}`
  })
  .then(response => response.text())
  .then(html => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const newResult = doc.getElementById('personal-result');
    document.getElementById('personal-result').innerHTML = newResult.innerHTML;
  });
});

// URL search
document.getElementById('link-search').addEventListener('click', function() {
  const query = document.getElementById('link-input').value.trim();
  const linkResult = document.getElementById('link-result');
  
  // Validação para campo vazio
  if (!query) {
    linkResult.innerHTML = `
      <div class="result-container">
        <p class="suggestion">Por favor, insira uma URL para verificar</p>
      </div>
    `;
    return;
  }
  
  // Validação para formato de URL
  const urlRegex = /^(http:\/\/|https:\/\/)/i;
  if (!urlRegex.test(query)) {
    linkResult.innerHTML = `
      <div class="result-container">
        <p class="suggestion">Por favor, insira uma URL válida </p>
      </div>
    `;
    return;
  }
  
  fetch('index.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `type=url&query=${encodeURIComponent(query)}`
  })
  .then(response => response.text())
  .then(html => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const newResult = doc.getElementById('link-result');
    document.getElementById('link-result').innerHTML = newResult.innerHTML;
  });
});
  
// Password search
document.getElementById('password-search').addEventListener('click', function() {
  const query = document.getElementById('password-input').value.trim();
  const passwordResult = document.getElementById('password-result');
  
  // Validação para campo vazio
  if (!query) {
    passwordResult.innerHTML = `
      <div class="result-container">
        <p class="suggestion">Por favor, insira uma senha para verificar</p>
      </div>
    `;
    return;
  }
  
  // Validação para mínimo de 4 caracteres
  if (query.length < 4) {
    passwordResult.innerHTML = `
      <div class="result-container">
        <p class="suggestion">A senha deve conter pelo menos 4 caracteres</p>
      </div>
    `;
    return;
  }
  
  fetch('index.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `type=password&query=${encodeURIComponent(query)}`
  })
  .then(response => response.text())
  .then(html => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const newResult = doc.getElementById('password-result');
    document.getElementById('password-result').innerHTML = newResult.innerHTML;
  });
});
});