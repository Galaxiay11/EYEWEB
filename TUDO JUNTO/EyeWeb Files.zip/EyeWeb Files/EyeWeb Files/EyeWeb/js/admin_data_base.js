document.addEventListener('DOMContentLoaded', () => {
  const userIcon = document.getElementById('user-icon');
  const userPopup = document.getElementById('user-popup');

  if (userIcon && userPopup) {
    userIcon.addEventListener('click', () => {
      userPopup.classList.toggle('hide');
    });

    document.addEventListener('click', (e) => {
      if (!userIcon.contains(e.target) && !userPopup.contains(e.target)) {
        userPopup.classList.add('hide');
      }
    });
  }

  // Submenu de secções
  const buttons = document.querySelectorAll('.submenu-btn');
  const sections = document.querySelectorAll('.data-section');

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.remove('active'));
      sections.forEach(s => s.classList.add('hide'));

      btn.classList.add('active');
      document.getElementById(btn.dataset.target).classList.remove('hide');
    });
  });
});
