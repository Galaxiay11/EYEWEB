<?php
session_start();

if (!isset($_SESSION['user'])) {
  header('Location: login.php');
  exit();
}

$conn = new mysqli('sql106.infinityfree.com', 'if0_39261598', 'UO9jt5N3Z2GpvV', 'if0_39261598_eyeweb');
if ($conn->connect_error) {
  die("Erro na conexão: " . $conn->connect_error);
}

function renderTable($result, $title) {
  if ($result->num_rows > 0) {
    // Obter todos os nomes de colunas
    $fields = $result->fetch_fields();
    $columnNames = array();
    foreach ($fields as $field) {
      $columnNames[] = $field->name;
    }
    
    // Resetar o ponteiro do resultado
    $result->data_seek(0);
    
    echo "<h2>$title</h2><div class='data-table-wrapper'><table class='data-table'><thead><tr>";
    
    // Cabeçalhos das colunas
    foreach ($columnNames as $col) {
      echo "<th>" . htmlspecialchars($col) . "</th>";
    }
    echo "<th>Ações</th></tr></thead><tbody>";

    // Linhas de dados
    while ($row = $result->fetch_assoc()) {
      echo "<tr>";
      foreach ($columnNames as $col) {
        $value = isset($row[$col]) ? htmlspecialchars($row[$col]) : '';
        echo "<td data-label='{$col}'>$value</td>";
      }

      $id = $row['id'];
      echo "<td class='action-icons'>
              <a href='editar.php?id=$id&table=$title' class='btn-edit' title='Editar'><i class='fa-solid fa-pen'></i></a>
              <a href='eliminar.php?id=$id&table=$title' class='btn-delete' title='Eliminar' onclick='return confirm(\"Tem certeza?\")'><i class='fa-solid fa-trash'></i></a>
            </td>";
      echo "</tr>";
    }

    echo "</tbody></table></div><hr>";
  } else {
    echo "<h2>$title</h2><p>Sem dados encontrados.</p><hr>";
  }
}

$personal = $conn->query("SELECT * FROM personal_data");
if (!$personal) {
  die("Erro na query personal_data: " . $conn->error);
}

$links = $conn->query("SELECT * FROM malicious_links");
if (!$links) {
  die("Erro na query malicious_links: " . $conn->error);
}

$passwords = $conn->query("SELECT * FROM password_data");
if (!$passwords) {
  die("Erro na query password_data: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>EyeWeb Admin</title>
  <link rel="stylesheet" href="css/admin_data_base.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">

 <nav class="navbar">
   <a href="admin.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
    <a href="admin.php" class="nav-link">Add Data</a>
    <a href="admin_data_base.php" class="nav-link active">View Data</a>

    <a class="nav-icon" id="user-icon" title="Login">
      <i class="fa-solid fa-user"></i>
    </a>

    <div id="user-popup" class="user-popup hide">
      <p>User: Admin</p>
      <a href="logout.php" title="Sair">
        <i class="fa-solid fa-right-from-bracket logout-icon"></i>
      </a>
    </div>
   </div>
 </nav>

  <header class="header container">
     <h1>Base de Dados</h1>
    <h2>Verificar e alterar informações</h2>
  </header>

<main class="container">
  <div class="submenu">
    <button class="submenu-btn active" data-target="section-personal">Dados Pessoais</button>
    <button class="submenu-btn" data-target="section-links">Links Maliciosos</button>
    <button class="submenu-btn" data-target="section-passwords">Passwords Vazadas</button>
  </div>

  <div id="section-personal" class="data-section">
    <?php renderTable($personal, 'personal_data'); ?>
  </div>
  <div id="section-links" class="data-section hide">
    <?php renderTable($links, 'malicious_links'); ?>
  </div>
  <div id="section-passwords" class="data-section hide">
    <?php renderTable($passwords, 'password_data'); ?>
  </div>
</main>

<script src="js/admin_data_base.js"></script>
</body>
</html>