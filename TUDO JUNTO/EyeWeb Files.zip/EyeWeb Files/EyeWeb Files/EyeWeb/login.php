<?php
session_start();

// Redireciona se já estiver autenticado
if (isset($_SESSION['user'])) {
  header('Location: admin.php');
  exit();
}

// Processa o login se o formulário for enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Conexão com InfinityFree
  $conn = new mysqli('sql106.infinityfree.com', 'if0_39261598', 'UO9jt5N3Z2GpvV', 'if0_39261598_eyeweb');

  if ($conn->connect_error) {
    die('Erro de ligação: ' . $conn->connect_error);
  }

  $username = $_POST['username'];
  $password = $_POST['password'];

  $stmt = $conn->prepare('SELECT * FROM users WHERE username = ?');
  $stmt->bind_param('s', $username);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    if ($password === $user['password']) {
      $_SESSION['user'] = $user['username'];
      header('Location: admin.php');
      exit();
    } else {
      $error = 'Senha incorreta.';
    }
  } else {
    $error = 'Usuário não encontrado.';
  }

  $stmt->close();
  $conn->close();
}
?>


<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - EyeWeb</title>
  <link rel="stylesheet" href="css/login.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">
  <div class="login-container">
    <h1 class="login-title">Faça login aqui</h1>

    <?php if (isset($error)) echo "<p style='color: red; margin-bottom: 1rem;'>$error</p>"; ?>

    <form class="login-form" method="post" action="">
      <label for="username">Usuário</label>
      <input type="text" id="username" name="username" required />

      <label for="password">Senha</label>
      <input type="password" id="password" name="password" required />

      <div class="button-row">
        <button type="submit">Entrar</button>
        <a href="index.php" class="back-button">Voltar</a>
      </div>
    </form>
  </div>
</body>
</html>
