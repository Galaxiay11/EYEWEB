<?php
session_start();

if (!isset($_SESSION['user'])) {
  header('Location: login.php');
  exit();
}

$conn = new mysqli('localhost', 'root', '', 'eyeweb');
if ($conn->connect_error) {
  die("Erro na conexão: " . $conn->connect_error);
}

// Verificar se existem parâmetros
if (!isset($_GET['id']) || !isset($_GET['table'])) {
  header('Location: admin_data_base.php');
  exit();
}

$id = $_GET['id'];
$table = $_GET['table'];

// Verificar se o registo existe
$stmt = $conn->prepare("SELECT id FROM $table WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  header('Location: admin_data_base.php');
  exit();
}

// Processar a eliminação se confirmado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm'])) {
  $stmt = $conn->prepare("DELETE FROM $table WHERE id = ?");
  $stmt->bind_param("i", $id);
  
  if ($stmt->execute()) {
    $_SESSION['success_message'] = "Registo eliminado com sucesso!";
  } else {
    $_SESSION['error_message'] = "Erro ao eliminar o registo.";
  }
  
  header("Location: admin_data_base.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Eliminar Registo - EyeWeb Admin</title>
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">

 <nav class="navbar">
   <a href="admin.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
    <a href="admin.php" class="nav-link">Add Data</a>
    <a href="admin_data_base.php" class="nav-link">View Data</a>

    <a class="nav-icon" id="user-icon" title="Login">
      <i class="fa-solid fa-user"></i>
    </a>

    <div id="user-popup" class="user-popup hide">
      <p>User: Admin</p>
      <a href="logout.php" title="Sair">
        <i class="fa-solid fa-right-from-bracket logout-icon"></i>
      </a>
    </div>
   </div>
 </nav>

  <header class="header container">
     <h1>Eliminar Registo</h1>
    <h2>Tabela: <?= htmlspecialchars($table) ?> - ID: <?= htmlspecialchars($id) ?></h2>
  </header>

<main class="container">
  <form method="post">
    <p>Tem certeza que deseja eliminar este registo? Esta ação não pode ser desfeita.</p>
    
    <div class="form-buttons">
      <button type="submit" name="confirm" style="background-color: #ff0000;">Sim, Eliminar</button>
      <a href="admin_data_base.php" class="back-button">Cancelar</a>
    </div>
  </form>
</main>

<script src="js/admin.js"></script>
</body>
</html>
<?php
$conn->close();
?>