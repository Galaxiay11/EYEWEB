<?php
session_start();

// Se veio do admin e existe sessão, destrói-a
if (isset($_SESSION['user'])) {
  session_unset();
  session_destroy();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>About — EyeWeb</title>
  <link rel="stylesheet" href="css/about.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="dark">


   <nav class="navbar">
   <a href="index.php" class="logo-text">EyeWeb</a>
   <div class="navbar-right">
     <a href="about.php" class="nav-link">About</a>
     <a href="login.php" class="nav-icon" title="Login">
       <i class="fa-solid fa-user"></i>
     </a>
   </div>
 </nav>

  <header class="header container">
    <h1>About EyeWeb</h1>
    <nav class="about-nav">
      <a href="#mission">Missão</a>
      <a href="#team">Equipa</a>
      <a href="#vision">Visão</a>
    </nav>
  </header>

  <main class="container">
    <!-- Missão -->
    <section id="mission" class="about-section">
      <h2>Missão</h2>
      <p>
        Somos uma equipa de cyber segurança a tentar criar esta ideia de projeto novo.  
        A principal função deste projeto é tornar a Internet mais segura, 
        oferecendo ferramentas de verificação fáceis de usar e acessíveis a todos.
      </p>
    </section>

    <!-- Visão -->
    <section id="vision" class="about-section">
      <h2>Visão</h2>
      <p>
        Imaginamos um mundo onde qualquer utilizador, desde o mais leigo até ao especialista, 
        pode verificar a reputação de links, arquivos, senhas e dados pessoais em segundos, 
        reduzindo drasticamente o número de ataques bem-sucedidos e fugas de dados.
      </p>
    </section>

    <!-- Equipa -->
    <section id="team" class="about-section">
      <h2>Equipa</h2>
      <ul class="team-list">
        <li>
          <strong>Ana Rita</strong> — Lead Developer & Security Analyst  
          <em>Especialista em pentesting e automação de deteção de malwares.</em>
        </li>
        <li>
          <strong>José Oliveira</strong> — Função aqui  
          <em>Escreva o seu texto aqui</em>
        </li>
        <li>
          <strong>Tiago Carvalho</strong> — Função aqui  
          <em>Escreva o seu texto aqui</em>
        </li>
        <li>
          <strong>Vanina Kollen</strong> — Função aqui r  
          <em>Escreva o seu texto aqui</em>
        </li>
         <li>
          <strong>Emanuel</strong> — Função aqui  
          <em>Escreva o seu texto aqui</em>
        </li>
      </ul>
    </section>

    <!-- Tecnologias -->
    <section id="tech" class="about-section">
      <h2>Tecnologias</h2>
      <ul>
        <li>HTML5, CSS3 (Custom Properties), JavaScript ES6+</li>
        <li>Frameworks leves para futuras expansões (ex.: Vue.js, React)</li>
        <li>Ferramentas de build: Webpack, Babel</li>
        <li>Infraestrutura: Docker, AWS</li>
      </ul>
    </section>

  </main>

  <footer class="footer container">
    <small>© 2025 EyeWeb — Todos os direitos reservados</small>
  </footer>

  <script type="module" src="js/about.js"></script>
</body>
</html>
